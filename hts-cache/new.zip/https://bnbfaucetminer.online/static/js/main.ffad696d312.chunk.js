(window.webpackJsonp = window.webpackJsonp || []).push([
    [0], {
        152: function(e, t) {
            e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAahklEQVR4Xu1dC9R2RVXeT9YSL5GIigIVeEMBQVBgKZBQKSIigQGigCQiBHLTFoKCoJgixU0EEZS4xUUuGiIoKYgoWGagkoKVImAEmgphWl6e1gNzft7/472cfc6cy/uevdf6Fkv/mT0zz5znndkze/aGhQQCgcBEBBDYBAKBwGQEgiDxdQQCUxAIgsTnEQgEQeIbCASqIRArSDXcotZAEAiCDGSiY5jVEAiCVMMtag0EgSDIQCY6hlkNgSBINdyi1kAQCIIMZKJjmNUQCIJUwy1qDQSBIMhAJjqGWQ2BIEg13KLWQBAIggxkomOY1RAIglTDLWoNBIEgyEAmOoZZDYEgSDXcotZAEAiCDGSiY5jVEAiCVMMtag0EgSDIQCY6hlkNgSBINdyi1kAQCIIMZKJjmNUQCIJUwy1qDQSBIMhAJjqGWQ2BIEg13KJWRgRIbmxmrzKzLczsiSN/3zOzm83sFjO7zcxuBKD/rzUJgrQGdTQ0igDJJ5vZ68xsFzMTQcrIT83sYv0BuLJMhbplgiB1EYz6LgRIbpCIIXI81VV5+cL/aGZHAbiqho6ZVYMgMyGKAjkQILltIsbOOfSN6DgSwLsz61ymLgjSFLKh10iuOLJabNogJOcD0IqUXYIg2SENhSTXHiHG77eEyJkA9szdVhAkN6ID1kfyZSPEeFQHUOwC4MKc7QZBcqI5QF0kVzCz1yZi/GEPINgCwHW5+hEEyYXkwPSQfOYIMZ7do+HrvuQlAO7J0acgSA4UB6SDpC7zihXjsT0d+mEAjsnRtyBIDhQXXAdJfSc6JRIxtp6D4WoV2QDAz+r2NQhSF8EFrk/yd0dWi+fN2VD3A3Bq3T4HQeoiuID1Sb5ohBgrtTzEfzOz75vZE8xs/RptfwnAZjXqP1g1CFIXwQWqT3LHRIw/6WBYnzWzEwF8qmg7HQQcZGb7VejPTwDUJncQpALyi1SF5FNG7IsXdjC2jyRi/MuktknuZWanV+jb2gC+VaHesipBkDrozXFdkhuOEKOO02AVFH4gUiRi/E8ZBSSvMbMty5QdKbMjgEucdZYrHgSpg94c1iWpdxc6jcrtNFgGDXngngTg/DKFR8uQ3M7MPuGsJ2/fdznrBEHqADaPdUn+zshq0aTT4CR4PpZWixur4kdSq4dWEY8cDEArVWWJFaQydP2vSHKdEWK05TRYAPOAmZ2SVoy766JVkSB7AjizTttBkDro9bQuya1GiNG206Au6XQadVpOeEjq5aF3axY2SM5JmGddyWlQt9368xqzOYb+6USMz+RQtlQHyfeb2SFO3VsBuNpZJ2yQOoD1rW66KyiI8ayW+/dLMyuOabVyNCYk9aG/1NnAWgC+7awTBKkDWF/qJqfBwj+qbafBO0bsi/9tAxOS95qZAj2UlZ8CeHzZwpPKhQ1SF8EW65P8jREXkJe32HTRlE6hZF/oVKo1Ibm6md3pbDBcTZyAzW3x5DRYbKPW7WAgMo5FjK900Lbetivgw+XOtj8IYH9nnUcUjxWkLoIN1k9OgwUx5LzXpmhLU9gXuvnuTEgeYWbeyCW1j3g14CBIZ9M+ueHkNChi6Pa4bfmamenXV+TohZC8zMy2d3ZmQwA3OevEClIXsKbqk1xlxL54QVPtTNF7RbrUk1dtr4Tkd8xsTUenCED2Wm2JFaQ2hPUUkBQZiiesIkmbcr+ZnZPsi39vs+GybZHU1vLHZcuncjcBkDNmbQmC1IawmoLkfCdi7FRNQ61at47YF7+qpanhyuk4+1pnM9liZAVBnMjXKZ5+DYu7ixfX0VWxrj402Rfa08+FkDzYzI53dvYAACc764wtHgTJgeIMHSR1NFtso36vhSZHm/g/M1MwNbmZ/3PLbddujuTZZra7U9HmAL7orBMEyQGYRwdJXeYVxMhiNDrav33EvvDu4R3NNFuU5NfNzBsw4vEAlCqhtsQKUhvC5RWQfMyIJ20XToM3mNkZAM7KPLTW1ZGUJ7L8vTzybQBreSpMKxsEyYQkSTkKFvZF206DGsWlyb74fKYhda6GpN7Ie2/vLwLwmlydD4LURDI95CmIodWjTfnPZF/IDaTV1GRtDJLkG7UaOts6FIBc47NIEKQCjMlpsCBFF06DMrbPAXBShe7PTRWSepG4r7PDtd+AjLYXBHGgT1InUAUxunAaVMyo0wF4Hfcco+xPUZJfMjPvcfgqAORHlkWCICVgJKlJKojRttPgT1LiSt1f6ERnMELyv83M86bjLgAKl5pNgiBToCSpW24RQ6Fy2pZvjtgX+lAGJSR1EqUbf49cAUCu8dkkCLIEyuQ0WKwWXTgNfs7MzgZwbrZZnkNFJHUSdYGz60cDeKezztTiQZAET3IaLIjRttPgz9M2SvZFlhvgnB9JF7pIKr/H25xt7wDg4846QZBpCCSnQRFDgZvbFrlxX5zuL+5qu/E+t0dS0VGU89AjawKQB0E2GeQKQlJRvwsXEIX6b1u0SlwIQMeYIWMQIPkfZvY0Bzg/BOAJ6lBK9aAIkpwGi21U206DmhCtFrIvloX4LzVLLRdKb8B1GvRjAF47oHZvSa5mZt4V9VoA2ZOIDoIgyWmwIEbbToP6JRQxZF/oZKq3QlJxe9+xJM3alQC2abPTJNWeXjh65HgAb/VUKFN2YQlCUrGiim2UEk+2Lf80Yl+UCvHfdgeL9lJURhHj7WY27gekdpR0z9hIHm5mR3vqmNluAM5z1plZfOEIQlIpiQtiKFVx26JbbtkXrW9NqgyUpLJJiRgbTan/KQCvrKK/Sh2SyunxamfddQFMTMLj1LWs+MIQhKT2nwUxlNy+TflRWi3OAvDlNhuu2laKtSVi7FNCx0cAKMtTK0JS4UI9HtFZoiiOG9xcEyS9FyhIoYjmbcstI/aFPGvnQlJKM5FjjZIdbuTXeVzbKZeJ3Gs88mUAjZxGziVBSCrXRUEM5cBoWxRI+eI+xY4qA0BKuyZieLYvL2jzqS7Jl5iZ903LaQD+vAwG3jJzRZB0ylIQQ1mT2hQZ2opJK/uikRD/TQ6G5GHphOpxJdtRUOqVcz1dLdmmwowqq+0JZcuncvsA+LCzTqnic0EQksqnJ2J04TSovN06ppV9USuUfqkZyVwoJdPRqvEHDtXfALCeo3y2oiT1VPj1ToWbAFD+w+zSW4KQVObV4u4iSxAwJ3pfGLEvFBlkroTkk9LplMLmeORSAH/qqZCzLEk9BtvAofPXZrYCgF846pQu2juCpHfIxTZKObzbFAVR02oh+2JuYkctBYikflh0r/FcJ3jvBaB6nUh6qSnHzd9ydOBrAJ7vKO8q2huCpPN4EaMLp0G5NYgYF3QV4t81axMKk3xOIsauFfTtAUAxqDqT5FGtC1aPnAvAGzertP5OCZKcBottVCPHdDOQ0L61sC9+WBq1HhZMxq1sjSoOey8GUDlFcy44SO6ZQqJ6VL4FgNeoL62/E4KQVCCwghhZn0iWHLkS0msb5c2aWlJ9e8VIbp5Wjar3QDqp0kVn50Lyg2a2n7MjWwLwHguXbqJVgpDceuT+otW2zUxJYOTCIGJ4gyGXBrStgsnXrPCfqtLsbQC0JeuNkLzOedqmvq8EwHuxWHrMjX+kaSKL1aILp0EFOijsi16G+C89W6kgyR3SCVXVJ8GfBNDFkfnUoZLUSqa3OmUlaxTFcY02RpDkNFgQowunQeXtLuwLHQXOvSQPAtkZb6oxmOMA/EWN+o1UTd+LN5V040fS2QmSBnqgmb1B59ONoDlZqaJ/FMe0IsjCCMm906pR56HX3gBO7yMo6TJYUeg9cgSA93gqeMtmJQjJI81M5PAsk94+jyuvG+6CGMqxtzCS7oW0anhz9C3FoFFjti7gJN9nZoc69byy6deZ2QhCUg5wMoLbFJ1eiBjnN2motTmgoi2SmhsRQ4Z43Zi/qwK4u4txlG2TpJ4hv6Js+VRuNQB6sdmYZCFIcgtRmMinN9bThxXLpaBYLXRcu3CSTvtEjs1qDu52AJ7klzWbq16dpIJve7aPdwLwlK/UuVwEOcTMskXUnjASAShiXALgHyqNtueVSMq1RsTQNrWuXA2g6t1I3bZd9Umuambfd1Uya+WtfG2CkJTfjIzjRzsHWLa4XugVK8adZSvNWzmSu6XtVI7kL4rju/+8YEBSWytvpJdjAMiFv1HJQRDdbTRx8SZnQV3qeU82GgUst3KSaydiyA8th7wNwLE5FLWlg6TsLO9p1M4A9D6nUekbQe4ZWS3kbr7QQvItaUu1cqaB7jVvrxw1bpIXVUiH/WwA/5oJt4lq+kKQm0eI0figmwZ1lv70rFS2hje05jTV2ePSzhpHrn8nqWgkWknLSiNRFMc13jVBrhwhRpaspGUR7qIcSeW60HbCe94/q7tbAJAf09wJyd82s/udHW8kimJfCHLfCCkU/GAQQlKv9LRqeF7LlcHmeQAUXWUuhaSeAnvJ/QEAOU76ZmLW5QqiG+/idGru3nrPRDYVIKl7CBFDCSlzS+MXZbk7vFQfyQPMzJtr8Q0A/qbpvkl/lwQZHV/xcEmnVguTrZWkQtGIHKtnnkw5Xz4WgCKPzLWQ/Gjy2/OMYwMAslsbl74QZHSg1yeXlcsAeCN8Nw5YmQZIbpyIsV2Z8s4yrRmozn5VKk5Sl77Cq6w8AEB2SyuSgyB6k+B9R1x2cEpHpm3Y5X33JdKAUqTHwn+qiYvT3j1yKjuR48olf7MHtBo69DQWRXFcH3IQRFEOs2b1mQDWVYksCqScLc2vY2KmFk23wTqh8qYtLtuFGwE0pbtsH7KWI6kDC4X58cgZAOq8h/G0lcUGEfvbPqKVk6Ju2uWP81+uEWcunBw1tWo06dqRPXtrZhgqqSOpN0OyQTzy5jYzc9VeQdLWQmEfW2P1CJpM4UCVckBkaext8oQtgiIAihxKudCUnAPAG2mwqb5k1UvyxAqOmZsCuCFrR6Yoy0WQJu2QslgUmWLl9CayNJZbPKVy03ZKqYqblBMAyB1lIYXkZ83sjxyDU2C/FQG0lpAoC0HSKqLXhEc5BttkUV1GXiqimNlVOQElqffcWjWafjXZ+HPSJiegjG6SShnhSbl9M4DcF61Tu5qNID0kSTFwhfuRzVKQpdLdAcktEzH+uMzk1yyzH4BTa+rodXWSSpDjvSA+D4CeBbQmWQmSSKJUXbJHtm1tFOUb0r2KkkMWZPnlrKokV0z+U3oU1oa8BoC8WxdaSO5kZt5xtu7Kn50gxaymZ6MKFKe/LsL+zPrAvpuIIntFhHmEpEnUdmr9Wcoy/fvLAPx9Jl29VkNS7z+8gbJbx6cxgowQRVlT9fSzz2RRDhCR5HoAl6S00QqirWPItqTVTE5tDWpSOyS17fV6GjwZQKsxlBsnyChA6Xmu9vB9JouOjlvFxczWBNDGZWvXvFjWPkn9KD3D0aFOvAja/hBGAZIrhjLT9pksjvmrXFTHlo0dSVfuVYMVST7NzLzhehSso/XUGJ0RZMnKott4vW1/eY9tltyfzH0AnpBb6TzoS/bpWLtvSv+PAvCutsfXC4IsIYs8NUWWly4wWb4LoI0YYm1/T6XaI6kXlYqk6JHtAbQeB613BFlCFmWy1f1DsRXr42mYZ5JV9qsAXuittEjlSZ6X8sN4hrVGF2+Fek2QJWR5YlpZRBhtxeaRLHMTzM3z5XrLktRjJ8/R+R0A5DXeuswNQZaQRWnGtA0TWbQVmweyKL/6Lq3PcM8aTIEr5FT6KEfX9MRBF9Cty1wSZAlZ5MsjoogwcnzrI1lOAfDm1me3hw2mlHHemGetRFEcB9fcE2QJWRTjtSCLCNMHshwN4J09/FY76RJJ5SBULkKP7Argbz0VcpVdKIIsIYuSgxbbMP23iyjnBwHwRuzINbe91EPyQ2a2j7Nz6wD4prNOluILS5AlZFnDzN5tZm16gu4O4Nwss7RASkh+0cw2dQzpBwAU9b4TGQRBhCxJ/Wrp16sN2WaSA2Qbjfe5DZIy0HV8X1auAeB5VFVWb6lyQyKIcrMryU/TIWMOBPCBUugPrBDJ55vZTc5hnwTgIGedbMUHQ5C0iigyiu5QmpLWH/Q0NZAm9JLU2/qznLo7jVg/NIIckWwR5xyVLr4HgLNLlx5YQZJ/ZWbeFNQbAWgq7trMGRgaQeSyomB0TcncRllvCpBRvSS9K7iCyq0EYObLz6b6PzSC/KaZKaWborA0IUGQKaiSVAo9T5zizoPlDYogyQ6RAd1UkLcgyASCkNSlrTc50ukA9m7il6ysziESRLGsLigLkLNcEGQyQV6dgpJ7IN0fgPfW3aN/ZtkhEkSv2RRRXDftuSUIMpkgVeKmdY7n4AiStllaQZqIitj5hOZmfC59JBWlX1m2yooM85UBeNOzldVfqtxQCSIbpInLvCDI5BXkW2b2nFJf5UOFWo+iOK5vQyXIemmbtYJjwsoUDYKMQSlFwL+7DIAjZc4FsLuzTvbigyRI2mbpPkT3IjklCDKeIEp3/Rkn0IcA0MVipzJkgsi7VzfrOSUIMp4gbzWzv3YCvTWATzvrZC8+ZILIQ1Th93NKdoKQ3N7MFOhZW5RbAHid/XKOr5IukspIu4ez8qp9SLs3ZIJo7EpFLS/fXJKNICRlJ+lXV2/uC1FejGO7iA9VByCSXzEzTySXWwE8t06bueoOliACsOLrtmnYZyEIyU3MTKFxJj0Z1r/Jrf5HuT6EpvSQfJyZKZ6u50CkkyiK4zAYOkEUZeT8jB9HbYKQ1PNgEWC1Gf3SZecBAJRjvrdCUolH9Q7HI0cCkI3YuQydIHrKqW3WUzPNRC2CpEy5eqarGGBlRAlMRZKcJC/TbukyJJUrRjksPbIDgI97KjRVdtAESdsspWrbIRPAlQlCUr5KWjk8W5Gi253ErS2DGckqzqHPAqDo751LEIQ8wMxyRR6pRBCSCiZxTs2voZd2CclrUiimssP7HgAF2eiFBEHIddI2yxPpb9LkuQlScQsyqf3e2SUklSPySY6vvVc54QdPkLTNUqS/zR2TmIUgJA80M+UKzym9sUvSUbVsPI90FkVxXCeDIA8d9x5tZod7ZnFC2dIrCMnDzOy9GdqcpKJzu4Tka83MGxHxdX06dAiCPEQQHa1em+FjLUUQkk24uYzrfqd2CUn9AOiHwCPrAfiGp0KTZYMgCV2SXnfscfMykyAVI3vU+QY6s0tIXu5MB34vAAUj740EQR4miM7qdWZfR6YShOQpZrZvnQYq1u3ELiH5HWdM5M8BUJLX3kgQ5GGCVElsv3QiJxKE5Jlm9mcdz3xrdglJBQsXQTxyIoCDPRWaLhsEeZggK5vZbXrmWQP0RxCEpEINyRbYuYbenFVbsUtIvsrM/s7Z8TcC+KizTqPFgyAj8JK8zMzkXl5VliMIScUB1gepj6WuKLqgxyN2WnuN2yUk325mf+kc9CZ98y0LgixPkCrJXUa/gWUEISljU+TIsafWSdBF6Vg4V7CJRu0SkvIP86ScU674pwD4uZNUjRYPgixPEAUV0GlWVXmQICTlKiFyePJgTGpzuWjxJN9jZu+o2sEx9RqxS0h+3fnW5gYAOfDKCI1ZEGQJnCSvN7PNKqKs+xS5Vsgjd8OKOkarjY1sTlKv83THoBhfOSSrXUJSSVbvMd/39WEA3sxTOcY+VUcQ5JEEOcrMFOSsipxqZjuamT6QOvIrM3v9tLx8JEVikSSHi4z6ms0uIak8kXJS9EjnURTHdTYI8kiC6IPzZmH1fAizyiqiudK3zXwPQVLvWY7JeHycxS4hWSXu2MxL1lnANfHvQZAxqJK81czWagLwGTrvTeRwhcipeGI0rSu17BKSp5vZXg78FEVxlT4+IQ6CjCfI+8zsUMcE5yh6eyKHbCC3kNRFp7Zcz3BXHl+hkl1CUt+UjqQ9NthNADzlMw1xtpogyHiCKNKJTmHaEp2c7Qbgq3UaJLm+mb3fzLaqo2ekrtsuIal0Bac52z8HgNKz9U6CIBOmhKTctOWu3bSIFLI5suQBJ/loMzvOzHSnk0NK2yV86PHZx8xsbWfDeld/srNOK8WDIJMJso2ZXdHwLGg7JXJoe5VVSCozrLZcj8mkeKpdQlK3/MrP6CWHutebN+hLsQqCTPl6GnZNvzptq2SYNyIkldH3WOeF3bS+yC45G8CyiJQktZ1TkOmqq+1VAF7RCAAZlAZBZoBIUjGdFNspp3wikUNHuo1K8qrVlquOj9nSPir86XVmpotR5T6vI73dXmlQQZASU0uSJYqVLSJv1TcB+HXZCjnKkZTxfkgOXRl1KLTPiwAo8mIvJQhScloqPh9dqv1wAF4P15I9nF2MpN6jKKVAHZf+2Q2VL7EvgA+VL95+ySCIA/P0xuH4CncNnzezM/oQjCCFAj3BzDZ2DL2JotcCyJ2fJXs/gyBOSEnq11fvO7ZNf3oQNUkuVNhNACJIb4SkQpsq3JAC1nUh2rJuB+CTXTTuaTMI4kFrSdn0WnDU8/cXZqaI6w/+AdD/7q2QlNu83Ofblh0BXNJ2o1XaC4JUQW2B6qSYwFpNVm9pWDsBUMbbuZAgyFxMU7OdJLmumckuyfH6cVJnb1HKOwA64p4bCYLMzVQ129G0XdRKkstFZbTD8u4VORq7FG0KnSBIU8jOqV6Su6ZoiFVcRpaOWg6fxwGoG7m+MzSDIJ1B39+G00mdAkUoO20VucvM5Hx4MoCfVVHQlzpBkL7MRA/7QVKZgBVFZSMzkyv9NNGtuOJgyQXlCwDu6+GQ3F0KgrghG2YFksrxoctFkUUhevR3f/rvHQBkhC+cBEEWbkpjQDkRCILkRDN0LRwCQZCFm9IYUE4EgiA50QxdC4dAEGThpjQGlBOBIEhONEPXwiEQBFm4KY0B5UQgCJITzdC1cAgEQRZuSmNAOREIguREM3QtHAJBkIWb0hhQTgSCIDnRDF0Lh0AQZOGmNAaUE4EgSE40Q9fCIRAEWbgpjQHlRCAIkhPN0LVwCARBFm5KY0A5EQiC5EQzdC0cAkGQhZvSGFBOBIIgOdEMXQuHQBBk4aY0BpQTgSBITjRD18IhEARZuCmNAeVEIAiSE83QtXAIBEEWbkpjQDkR+H+Bvp8yTYfoBwAAAABJRU5ErkJggg=="
        },
        166: function(e, t) {
            e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKUAAAClCAYAAAA9Kz3aAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAApaADAAQAAAABAAAApQAAAACbonp1AAAj4ElEQVR4Ae1debQcVZm/t6qrq7vfkhWYP4YzzgzH4SiS95Izjs6RbASIOAwyLI4IkgWigAKaBJQ1JBFcEAVUBCSBbGhCNplB0ISXRZ1xzpCXMOMcPTqKoweUJcnr7vd6qeXO77vdlXReXr+u7q7qql7qn+6u7rp171e//u79fd93v4+xzlG3BEZePOv07N6+x15/vv+UuhvrNMCUjgzqk0DqxbNP1bq1tXpMXXJKD3/8t9v7JtbXYufqDijrwEB611mnxbrVTarg56aPmkzl7MOnn6quPdIBZh1SZYzXdXUbX5wcmDE1rtnrVcbnDw9bxyTZnVCZJdiWZJZfN/m8l4faWEQ1D72jKWsQXXLXe6fENWujytj84ZHjgKSm0gCoorDLe+L2k28/f0ZvDc23/SUdTVklBFIgM9FevkFj4vzhEbvs1aQxTVtsTeWUxR2NWVZMY37RAeWYYhn7JAEy1su/G+Fibnq4PCCdq7u7AExLfB/A/HgHmI5UKr92pu/KMpK/IJYd62WbMGW7AiRdRFN5ROH/2BsXID/v6LByl7LuaEoXgiKWrce1jcSyS0mNi0vlT+RUzsTOiCEW8DkHj7q9rl1/19GUFZ48sWw9EX0qIlhNgKTmpcbk/GIrwp8Q//53HfJTQeYdUI4jIPHC+yfrmtio2mx+mkhNrfMKriNgqpxfZpnGGrHzb3rGuW3bf9UBZRkIkMvQ7M5tLLBsmH08OCQwGbvUnJRY8/bzHY1ZTqQdUI4hmT9uO/vUqRP4MxFph6zMssdoYuxTpDFh1wT5uWxCj/H0/27+qwlj/7C9z9Y6IbWs1MS+/lMshW1SGJ9XC6lxKxjp+WFsu5rhC3nH83OC2DqaskQcZPaxVLbRb0DSLUljQviXmLq9Tgx0gjhKHkMnSsgRhvjpuyfHutSnVMHO81NDOvejV3JRqrBjmmDlnTXmccl0pm/IQsCXbcYMBFewD47nOjwuNm/fdVySJ8qz7afv156bMdWKGyA1PBBA0uOQ5Efll/ZgKu8EcdRueTsR2k36SYafRcUGVYgLgtCQo8XmkJ8kyE87+8rbVlNScEVCApJdMOwiuGI0gPz4TBoTS4hLCr7y9iU/bQnK5K4zp8Qm8DUAAAB5YjykH2Crpk0HmN1TlMcPt6kds+2IztALYNndUcRDBkNq3AK0iyLYEY+ZTKcWTbnw10m317XC79oKlAIa0ozF10FDXhiGNWQlABVZ+bMA5uJ2AmbbgFKafeLmJrgOzycfdLMckvwItmMopV0z5cKftYXGbIs1ZVKafUzEQ4qmAiT9ceQaE7sk4St/6vCP2sNX3vKaklh2fAJbrwgeOlJTjbZ2NGbqLXvhpEtaO1C4pTUluQ6j3eypMLLsagB5TGMq7MPdU5XHW93A3rKgPPov75lkiuh6TWEXyk1eLTAnFCLY2eW9PT1PvtnCgcItCcrktvdO6Zqoki+7KVh2NVqzAEx+2aTJXd95e0NrBgq3gP448ZGSYTwRj1OigAvcbIM98erm+STNRWDlyRZk5S2lKV/ffMYpup7YqIjWBiT9dWQQB7HyXmPt4R/NaKkI9pbRlClEjMdUjuAKdn7YXId+6l/y/NjQmK3EyltCU0rXoUIsG6lUQubL9hOQ1LYMFIbG7AErFz9ujV2STQ9KSjYFX/Z6pOG7UEb7tIzudw/nooH9clN0PdkKU3lTP0Ji2fFTjWcASGxh8HDXoXs8hOqXRV/5zoiSuJp/4CepUHWuis40raakiPHEqeYGsOwOIIsPXJIfBZk4xMhTzbznpyk1JUWMJ3SxXkHmCpkfsop/oR8/5ZBiLKqwbN5mQvhxh+raLLgkxbZkVlnUjBHsTacph+A6TGj2Gph9Chl0q3tenv8auxFZRGU5wxTPRyKKiY+BH6QxFc7/qVe3H2tGl2RTgZJchwmhIx6SXxQGlk2AjEYV02bKrbH9By9SVeXuWFyxAYjAgUkziKLwj/T29H6n2VySwUvP5eP7Azw1p8UST8Ps86EwBOgSIPUYN3KGWJ6Yc/AhZxi5vdPviKhiZTZjK7AfBn4UyI+9JZlOX9ssgcJNAcrktjOnxE9LSNeh1JABP2oJSF0xDUssjc0efHh0d44DUwCYwSOzAEy4JP8PgcJXhT9QOPSgLCYKIJYNUhO82YcAqWncNgzx2cS84xpyTGAqYlU2Z3M7+G4zAqZgYuuRZPj3/IQalAIs24xgXzYPx65DVH1gWkS1TNNeOh4gHYAa+/pu54yvzhEwg1eYEpimsLdHskkk1fpNaMuphJbokOswr4mnVC4Q7RP8NliQBqbrqukWkARMbebB+6Cd7ozFEPceAvJTsGMqlxix3lC7JEOpKSkLmakp0JAgNSHw1Dgs27TsZbESUuNoxEqvco0ZAfkZCdMa094SsYxFfM7P05X63+jvQ6cpBTSkqfF14QIkN7OGvbwWQNID1Wcd+IJtCpiLOMxFjX7EJ99PBgqryuWGooUygj0EIjouNBmgG4tvwIODYTx4diA1pKYgTbm9NDYOqTk+gvHf5fb33YFEWquy2ZCsMVHnBwkPtg39LrVwylXhSXgQGlAmn3vn1MSUrnVwHQaW/awUUsdYtg2WXcOUXdpW6fsi+fkCyA/FQQZ+UAEqIcTWo6+hMtoV4aglGQpQykpeE/h6BOgi+1nwiQIkqYGnJp+3l7lh2dUiK7e37w5UilgFXzkXwU8ITAYKMxuprtVQpLoOfE1J8ZCodbgW/9fQADIGwziRGj8ASQDWZx38giXEXfFYeFySKlMusWLW42GIxwwUlL96+IO6rhtroyr7UBg2edGUrUe5mcvXTmrcak0Cpm2Fi/yoEfWKLt1+VGymjITBHYGC8g+HMxYX7HnTFDkNFvIgjwIgoSHJl33uwa83oi/arIP3wQ1ZDOJoxB3L3yMS4Qxeqqwp2G72P3D+BHgEi4TiwPN7+xfBW/KtfF7oFiq4N/qQpCYqXYdLGwXIkjFyY+/02xVySQbEyiNQCBGdZ0ybL4nPPLChpG+BvA0FKGnk+T3TF3JVPGo0GJgq5gpyHVoCZh8PWXa1T9MA+YHXZ1WjXZIESE1XRizLXoIlxcZq++3H7wOdvksHFJ19YK2w7Zt1nedIczXiKLBsFTN2sICksWIql+RHh0uyQcOncikEyIxtWp8KCyBJFqEBJXUmOuvQY1BZN0VjShal4uiUb4ezhszBU+OlHbKeDktWbrO7C8D0d/ykIREPOmwY9g3R2YfW1tNvr6/1d+Q19jazr2+Bxvm3aSo3fVhjqnggUY2bedO+NTH30Ndq7KZvl+X29t+JLRb3+hUoXFhDkoYUi/XZg8/4NpAaGw6VpnTGEJ958Cnbtm+IRHmeBOjlQRoSm7wKLDuEgKSx6rMGV9sWu8ePrRUOIE2DLQkjIGn83j5xatHDIzPQv1iNsG+ZORGFj7bulmkNCQ1pWyZfGjv3QEPMPvV0Ord32p0qV4j8eOKSlICMKhnMPp+Izx5cX0/f/Lw2lJrSGXB8zuCTWPNcT2vMeskPBehGEVxhNAkgSQb6rEOrBRd3RvX6yU+R1IyYJrsuzICkcYcalNTBrrmH1mBz1mewKM+RpqvlKLJsWD3YskQTaMjSMWrnkOfHvrueQGG5ho5hDWmzG+NzDoTC7FM6xtHvQw9K6nDXnMFvGwa7Bay0ao0p15DwZedNhnjI8E/Zox8QfdbnHFqNNfbd8QTFY1b3x6QpGzPNCAB5Q3TmgafGaj9s56obYcC9z7zUv0jT2LfcsnICpA5A5gwGln0gdCy7WnHm9ky7CwkPVrhl5SWk5rpm0JCOPDzTlL/f/OdxUBFfQR6fO7jGNtmNbli5BGSUW9CwvgNyxYoVypEX+qc5QvXrVZ8NjWnZ99BUXmklcwyQJkiNz1P2ihVM+dXDZ+hejdsTEL2OsiBTJ/J1LG/v02YfvN+rzpVrB77yxSAu3zRysGOOwcqJ1OiaIvIWdh02wOxj7Jl+K0/w281h+3MxLDXK9dur8wZYOQMrz5dh5Y1m2bl9/SsRUPOuI0NJT0r21a0pUy+eferUXmUjKnnN5wpbnRvov9Mr4ZdrJzoLrNzi12tYY44mP6RBAEgrb/GGAHJkYNptXGX3GWlrQkRjX8/u6b++XL+9Oq+BlTOwcixNTtKYRGrIl23a9rWNYNnw2a/GLe/EUvdSpIhBAar6U13XBUqZQbdLWYtNXuelUhbL5SEjjmiXgf6lXj2Acu3E4SuHgfmWGFg5TdV0SJatY1+2gOuwAWvI7EDfLdAQ9+VzFvbeCpbPCh2emK9lBs5eXK7fXp0nVg5rwj2lLknSkCA1mazJPhWfdXCTV/cq146xfzoFkdyRQ3RTOm0xRL9dQkm16s1dVPP0TZu8dD1OdWo+WLrJqwAMZpsmvxVT2VfLDcir86SZtAh/EFEVMTUC16EhbkvMHXzQq/bLtZMfmH6LoooHEG6nlhr2C1Mnz8MeeAPZWctd79X53J5+kB+2Ah4aRdX4CFLJfDo+a3CNV+2Xa4cAqTCxKgNAlmamoT0/iF/43lA6uqTWWpI1gZIAGY/Fn8HOvPNog/voQ67potBYlritEcDMDPRdG+uOfCmTNO9HPOQDo/vj9WdoyJs1TXkAGiJSCkjnPgRMLcpztMQgje6c9+mV5wb67tG61Zuxpr0p6r+nhsM3jyRe5X3zEpg223bk8PCCUy7+ZdUZhasGJe06jE/s2gC5Y09N+V1PBY2J7almY4CZGjj7rO7Zr/wca5v6/ZHjoCe7p2+5pir3wfU3JiCdSynKida8pmXdEkP0k3Pej1cxMDsybCXf1T3vwCt+tF/aJrk+I6qCYJHxEysUE7c+qx5OLOIXV5fquipQVlt8kwy92IRlYUppiMYsFZ4f76Ehl2HbwBdzWaG6yaZGa90o1rz47U3Rcw4+7kefGtkmkVgsFVZmsnB+ls7ZZTohgWmLZzGVo165+2xvrokO5YeMT+DIoMtd5/ahB5fNW6qqii8be6Z9tkzfm+J0fk//TdAQAKTtCpA0KJraifwoXHkoj3C8phhomU5S6hkEx6ykLRtuAEnN0NIO1oDLerrzVZEfV5pSUPHNiRFKx1dTrUMZDBFFQmjbXqbNPuQ7CSkj15pP5/f23awoyleJZYPxVn2QxtQQUY893jfAnOU7Cam6gxUuKG7VoOxxNUUrOeTnsJW/9lQXuYsqakoqC2JO0uoqvkn5GWHo5niwX26EuaiCjKv6msw+BUDaNQGSbkYa00TAMsJfHs3vn7awqg4E/GMCpKLylbkcdEqNq3XKXQSN+ZGJiu4q1fW4mpISBSTi5kZQfxRwr0FFjBIobdKKNpCVj7p91R/z+/o/DS33YC5nRayTjQxVtydZua5k4Sr8ZHTWwaerbqDBF+QGQGo0IjXepMourjG3QmMuGE9jltWUSapTEzM3KMIbQJI8aepDKhQVdsUvhV1jGnv7l4KoPYg1lCeApPHT1g4jZ8Oeqjya3du3hM6F9SANiX4idzuxbG96KdeYCr90akRf86sNZ/SWa3VMTSlZ9kROdWokqakyWqrcvY6dJ3NRTKdgCfvW2NzwrTFH9kxfjqwd92MNpdpePZFjo2dyFyGxcmRzuzk2x19zUcltXb+lXEcwaZ1kGHfdQIUfOhpTTacW8QtPzvZ2EiiHfvr+yTE7t07zOWFpgfxga4ItlsdCRH7gIboporAHkboFgKwg3Tq+luYiTOWGZd0QD9FuQif5Fv6QvqbELpKf76pW/rrRiVtPAOURZNBNaHyj5hTfrEPobi6Vnh8dswO2uWoh0Jj1smw3Yy79jQyeiDJQCHF99Jzgt7k6GrJRmTpIYxq2+J6WsRbzC14ZdmRzbE35B5QF6Y4q6xsFSOoAaaJ8TiiKpoKVT/M9iMMZ9Fiv5DpUFeUBhIPVzLLHane8c5SixswznTPl0cyeYFk5UsfAdchhhxS+ashSedAaEwEtHzHi6hNvDLy72/lOasqiL3sDojzmB5H9TK4xYxQhbn0uMeeQ70EczuCdV3IdwjCOaJ/xXYfO771+dVh5I1ySY/WdAIngksAKUsk1phDPHjk8soh85Xzkxb89XUuYjyOJZ6DFNwvkR7Fypv25+JvGw/yKn+fHEqCX58R/ztDMlHWzAk8NEpj6Qmrc9veYSxLkR2OTnuRz9phur631d796/gz9HV29yziSa8F1Cg3pEc2uoUMETARsP5vNWDcqim7che0F0JAeGOJq6IxzCRmYwcbVKOITM5PU6c55P18zQ2Y/qPD9edzXD5ZdTd/lVG5gKo/wB44M/+nMaq6t9benR3vOQSZKRLAHC0jqfwr4i+jKZYgHvUlB4s57YZr41x7EwQV5kKagKrCIi7w1Pkl7uRF9iU+IDMJ4+nmEoVmkqYM8iPQgcj0nTLFsUtdpv2hEX/R8aj/+jCuiOqfo7Ebcsuw9erqhKfP2NsMwH5E9oQjyRHd0PeIjLxwrPrJsSx59IddUmmKiZNzy7vMak7C0tOvtvqbM7Ztxt6rYK3IZf81ApTIvfS/XlAxVKpKoUgG7pWTfE+b//PDwUfMqzOnfJ/tRIw+5lgIgMYUGAkgaa2z2wa9gxlhK23GpP4086A+J5RPqhVs3+B13WW5c0Zkvr0KwiNxa0dDKaFjCdicUhg1+m39bBCT18YQnILDpx4zb6yOcX9SINSYBQBbf9LgsSDnhVzrf5nZKbvy4/06EJt6bySLrdwM4j9SQNtuiWrkTKp8ds1NKhJ738tCwMK+Bxnyuq+uEryo9z6q/lxl0KbdPSABJA0CQxEPwT38WheWxxqx6SFVdIGeIKEWmh8Nwjs4L7QODqxAteQ9mDOb3hEEzMnZcbhlKJ68d7dE5SfQTz/mvI5GcthB23R8Qkv3YXECkQtNUABL7sgNM6TwWiqh+N8rbfB7FQX0jPxKQ5Ps2rVvC5GIkeRAwEWKH3EUqipyOJaH6z0kNKdj2SE69jtaQo1s8CZT0Az7vP97OvKFdbTLxfJfHa0x6IDryQ8IeuSxsgHSEk5h94CvCFrfRGtNrVk5rSD0u0/HdFMZgDJKB1JhCrECdH89ZeRGQ25Kv8bKFpMb9L/werPzPuqPw9PAPerHGJLMH0vHJwklBJr13wFfptZ3jKbGk5Oa+/rugLVfQvm4vgqUIkNgevyOZ0q4Zb8/OmJrSeVing5X/MZ0nVv4clUqr55BTFtaQtZYnrufetV4bnTn4CAz6yykwmfpfz0EaUkVmYltY2BIR/gBfjFZEZg6uwpr/Xkp4UNdULlm2BOSWSoAkGbuSNEUPdWvKOqRmuagWOyZNgTKDriE+60U12HrAUcu19bJyAnQT79HhyBV0l8r4vYjAr2lLBCk0lP179mjRt13pGYyrKZ2LJ805eHRYGNfAULBTrjGrMBfI8DSsIeFGbEpAkgyIlcOOCVYO8uPqb+xIzgnoVbLYAYgtEM23aQwjEfrMwZUIr7sbVomqWXlxyt6cTEUXu01MUJWIBbbZWvH4OvAyV54fOWXDvALDODLoNt5Tcxwa3rxr+33f8PxEuL2iqn3fYNnJLF84GeZGt0/BlaZ0GuPzfvH2cCp/tUWsHJb48Y4iIOHLbgwgKUMGDL5V/cnG6/9Y34GcPQC74ueRH7Ki54cyZFCudkwRN/udiIAyZKR/NOM9Y/XZy3P6zJdXgl/ci6RiJ2V7G32foobcnny9OkBSO+Mja/Sd8Fm6JNMApmAvdpcxsBMgyZyCB7I81gANSbmEurujezMv9fkeKEwuSQPmLCz+ywKTSA2tIQ0kuWqA65Dn2dE7uyayvZmB6VeN8cg8PYWlzEr8+VfArFUWmNLsw8TOZCq5oJbC9lWDkkZIwBwZzl8Jev/caGAWttEiLrJQntj3siCUdQ1mpkfyaWsy1jz3j7zU73smDjJnWQYDK+cnsXICJGUaBiBvbEByK4asa0ilwu/Kp+1JSL39WAbFVz1F4ajGMBVJVg5f+YpCcYATfyA1JOIikxkFZp+TDeMn/nrsT3VNd0eROaNrgroOmvEfKGIdG67gqVFsKgvSiCoM+b3TP4GUMA8hQFWneExi+TDMW6Zt0WY033OcU6ICVWVfRQ52hbYPyyWL1JAWqjC80pA0gLj/vU6ArtTQyE+JlNqN+ENwg+yYDPenzBkYf8F1CECmU8gdVBsgCaZ1gZIaEAMzppqaWA9Azof2QDIr+674XP9TTGdQ9VZD4ScYdmOlAbrEjgmYyOTbkMSplMk3GlG/QAHKlP4PeSk/A1floyQbPw8qlYdZaeVow7Z0UCCTL57DdQ1InMpz+/vvQ0Kez9EfwhRiZ9oQC8haU8/Y6wYl3Vzu8UkknkZqlv2JOYNfqqdDbq5FsqhrEZT6jU7O87Fz+xSWEI2rLIYEqquRWvzdyRG+oBqWXe5ZewJKavy3a98R+8uFr+bwtgorZrlulT9PmSWw6/AbiFLWKONEuUOSLaoOYfLlMZ9TTVN1iJvft/M9k+YPHirXH4/Oo2D9tDuQ20hmPxvP9SeBibLJyA/qe8k7geoQr/7FO6J4/lkvxukZKL3oTKU2Mnv6rkPKF9KQ0fEA6bTjWAE6dXRQ+s7nsiWOzL14rYl9e3HjatvIDky/MRrhjyDfoytAUvtEfrAIj+ga+/LIS9M/U+09w/R7KlOCZFMo7OQ+tw/9cc2cHdei7PH8vukLwjSe8frSFJpyeKDvRj2K7GcZES0lNeMNrPQ72hQFuymCQdiyZiyFJ7OfIdmUW09K6djpfZH8UG3GpiiFF3pQFknNN7ENtK7yyjJ3EaKULJs3FTCN/X13MMGpkFNd4WPSXIUajYbFlsRnhbtoaKinb7JDcoV/E2VB6gIkaQuZIgZmG1URX83unn4LnQv7QUnvueCr6wUkjVPuq8/ZCZjunsjs6b86zGMPLSizu/uvh3Z7hEgNbdT34iBgGoZQolHxFTJ8e9GmX20gP6aswlBPBt3RfZNrzLwdhwfosUa4JEff3+3nUIJyeHf/J+E7/joSrGpeAdIRCGkMpGiJwGTylZGXpoWS/JBhXDlWp8abP6Qzfof8IPHB43BRftQ5H6bX0IESvuxPx3QG16HtmYYcLXBKFY0lQQSemC+P7A6XxnQ8NdWw7NHjq/T5GDAjmMoHwle1IlRERyYsRS4dAFKrhWVXehijvydfeYw2sVnh2MQmE5Yig+5o1+Hofnv1uUh+MrZp3RgNUeLW0IAyu6//k9ig9jDKgmi1lAWp9UHJ/ecRFasEe2mQm9mKZUFW+Z1Bd7ScyPNDVW9hlliizzq4cfT3QXwOxfQN1+GN2Jb2CFhmQwFJAqc/AOIjUYCKPxjQVA7XIfJDkoas0+xTC4BoKkdxgATG/wT2Il1TSxteXxOophSPzdBy77RvQmm1L9Iaz2tSU42wCr5yxaTdi40ITC72jSOY4XaFB5ew1JERaUxFQ8k+m3869sZfr+FXbAksN2SgmvIPk+A4VNk8/EsDBSQ9GOmSJFaugZU3iPxgyg4FIGn8VK8cwdK6ooi59DnII1BNSQNPIh4zrtnrMH0X6oYH3CNJfrCVg7Y8+LnGlEnvKcd4hWqwjQKH3MIg7M3JrLrEi/CzevodMAQKXU+9ePapsS51I/YWzxumjMIB96qwLVg1ER63zI996k5ZENhLObYVBH7QvmxEZm5XM2rZVCqN7GSg07cz0J4LXnkja6eutDj7ocz25q292LmN61fpksRUrmogP6ga4fpCFz809vXdjvzyVHwzFIAs5CMVW5OvhQOQJMJQgJI60jPz129m8vxjNuc/HL0Zjb5v9CF9xeSSRPVaKmfixf1zCK5AxFLN1WC96ENpGwRIjHPbkVdTi2rZdVjalpfvQwNKGlTvnJffGjnMP4ayCBX3lXsphHJtETApST+Y6QPpOskP2SFhh60YMV6uL56ex0xEgMS6eTPKhCyYclXtm7w87VexsYBXb2MP6eh+7JJkkU0wbM/3onru2Hdxf1Z6PuD5qTU5FxVwj0Rg9hmhAN2A1yYYdmEbrL0lYhknZNB1LxF/fxlKUNKQiwWnUByAIQ0h2EDAPZXbd8HKYeBflph38CG3j4XWkDRl1xqg6/Y+bn8nNaRtb9Z45lr+gV+m3F7XyN8F/KjHHyqx8ni3ivLO/LywsHINLknTRAZiF8AkQHJWIDXjbfIaXwrefSs1pLC3R7JJsOzfDHnXsrcthWpNOXpoxMozQwzkh4WC/BArByBVFA94cGTX+OSHpmxJamD2CQsgkTltazKVXhBmQBIGQg1K6mDPhYNvEvmBuehHBfMFnQ3ucFg59vw8QFFNY/VEriGp1iGVlguBHbKwhmQ7jrwaXVRP5oqxxurHuVBP36UDTj43Y6o+0V4fpaKmI8E/aekrj3EjZ4jlpbnbjwEyY4PUlI4gmPcOqUmm09c2AyBJSk0DSupssTLaRpCf0AATSbXMvCmWxucMfsPcP+M2RbFXh8V1WMigy7YcPTzsOmEpyTnoo6lAScISPztzimkWEreGgfyQxkQQAwrJ892o1nU+smtFwqAhpesQBd6H0qklzaIhnT9D04GSOl70lW+ArzwUrJyS1COCnfb+sBCYIaUdEjnGtyWzyqKggyscoFXz2pSglMB8vv+UWC9DEAc7bzgEa8xqhO7nb7vjcB1S8c1UFMU3f3ZS4SQ/7+1V200LShKADHuL2t9FDvZzh0cCi0n16lnU3U6B1IidkSOJq/nFPwmlYdzNIENvEhpvEOQrf2uIfdSgVNcVcrCP104rfFcwjLMtqZxyTTMDkp5FU2tKB0zJXe+dEteNDYjoL/jKW2JUzugqvxIgsdVmi8qHF4fVdVh5FMd/0dSa0hlGL2pJZkesa/Bgdldb58dpo1lfi2afHam37CWtAEh6Di2lU8S+/lNMFeQnJL5yv4EuNSRj25IZ3pQsu5x8WkJTOoPjMwffzJKvnHG4JFtqaM4Qj70Wp+ztQ0mtqsJJxxoI8ZuWe3LSV26wKxEo/INKBahC/FzKd40CdAtryM1Dv9MWNKvZp/wAW2z6Lh2odEl26ZtULi5oJTsmAdIUHMU304vc1joslUszvG85TekInQpQZUx+lcX4C9JcFILgCKdvtb5SlBS2Z6M8caSpfNnVjreliM5Ygy+4JCPk+QnF9t2x+ujmXEFDsh3pt+yFky6pr06Nm/sF+ZuWByUJNwVWHpOsvDldkg6pSWaPgtSEN2LcKyC37PRdKqAesHJ4fj5mK3xXs7HyIiB3DKU0FE5qfUDSc2sLTekA9HUEcUzu4QgUFheEIVDY6Ve5VzllU/HNOmsdlms/rOfbCpT0EMRP3z/ZtHKbIiEHpoyHFOJZlY8sahVPjds/QVtM36XC4H//b4czR/lVBTsm6E8IWbmcsm17i5pKtYQvu1T+bt63HShJKL0XvfxWdthaYCliV9h85RKQjG1Pv82W8DrKE7t5+GH9TdtN36UPQrLyCNuk2jAXhSBQ2AFk8jW+MEy5fUpl1oj3bQ1KEnCKItgnMAoUnhtkoHCR1HwfpObqZttT4zVQ23L6LhUi+coRxPHPBrN/GJSvvAjIrQjQ/Xi7A5KeTdtrSgegYhd2ScbjCHtjF8ikWg2STCEeEmafVHRxKwZXOPKt5rVBoq+mS8H9Nr3rrNNicW0jched24jtu9Lsw8RO1RAL+JzWdh1W81TbfvouFVb3vP/+UyZtXYmNsr6zcpqykecDKZ2xp6YDyNLHEP5cQif0tgEfKKnWW29YlLtot1+5iyTLFmzH7147Gooc4w0Qa1W36EzfZcRFLsmpvRxVK8R8z8xFFKBL4WfSddhZQ5YRfYfolBMMnRcvvH9yvjv3jMbY+V6Yi6SGtNnWI0eGF7ZqgO548nT7XUdTVpCUTHigi/VIEDS/5ozCpCG7ZdL7Z1Utupi/rzkzV1QQlWdfd0DpQpTEyvV4lMxFNbFyaYcEy450WLYLaTdB0lRXo/D5R8TKs2nzSuToKbDyKu4np2zyZb95pGP2cSm3jknIpaBkAaokuxKprsHK3YlNakhbfB/7srGF4dWjLm/V9j9zJ922F1NBAOSSzAyJj+YFr+iSLAJSug6bMR1fkI+8s6asQfoyd1HM3ARzEVj5qFTXIDUUDofc6FsRXNEUOcZrEIGvl3Q0ZQ3ipdxFGQPFARh7gVyFpYHCZIdEJl/KfgZfdrgqedUw1EAu6WjKOsSe3glWPlWj3EWSlRMgkWRrR8rENtiO67BmyXY0Zc2ig+3xYmLlFqrvit3dEyOUKGDH72lfdgeQdUi1c6knEhh58azTs3v7HqOyKp402OaN/D9MkxjChGgdtgAAAABJRU5ErkJggg=="
        },
        167: function(e, t, a) {
            var n = {
                "./en.json": 437,
                "./zh_CN.json": 438
            };

            function r(e) {
                var t = i(e);
                return a(t)
            }

            function i(e) {
                var t = n[e];
                if (!(t + 1)) {
                    var a = new Error("Cannot find module '" + e + "'");
                    throw a.code = "MODULE_NOT_FOUND", a
                }
                return t
            }
            r.keys = function() {
                return Object.keys(n)
            }, r.resolve = i, e.exports = r, r.id = 167
        },
        212: function(e, t, a) {
            e.exports = a.p + "static/media/logo.c70f9c7b.png"
        },
        213: function(e, t) {
            e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAARGElEQVR4Xu2dCbR2UxnH//9EhlRUshYSfUmZJTJ/ZMw8lmQOERmKZchUQihDRFgIIUMskSKUkAxFpizUkpKsSJIpPK3/13553e/e7773vOecvffZz17rrHu/dc9+9vP8n/37zrQHwosr4AqMqQBdG1fAFRhbAQfEe4crMA0FHBDvHq6AA+J9wBWopoBfQarp5rUKUcABKSTRHmY1BRyQarp5rUIUcEAKSbSHWU0BB6Sabl6rEAUckEIS7WFWU8ABqaab1ypEAQekkER7mNUUcECq6ea1ClHAASkk0R5mNQUckGq6ea1CFHBACkm0h1lNAQekmm5eqxAFHJBCEu1hVlPAAammm9cqRAEHpJBEe5jVFHBAqunmtQpRwAEpJNEeZjUFHJBqunmtQhRwQApJtIdZTQEHpJpuXqsQBRyQQhLtYVZTwAGpppvXKkQBB6SQRHuY1RRwQKrp5rUKUcABKSTRHmY1BRyQarp5rUIUcEAKSbSHWU0BB6Sabl6rEAUckEIS7WFWU8ABqaab1ypEAQekkER7mNUUcECq6ea1ClHAASkk0b0wzew9ABaeRtgG4GaSrxQmzajhOiAd7gVm9nEAiwD4MICPAlgMwDwDhvwLADpuB3AHyScHrNep0xyQTqUTMLPpAXwawOYA1qspPF1Vfg3gXABnkny5JrvJm3FAkk/RYA6amW6bBIXgWGCwWpXOuleQBFD+VcnCBCqZ2XQADgKwEslVJ1C1llMdkFpkjGckXDHUgXS0WR7pA+WJuhs2s3cB2A7AtgAWBbAvyWPqbmc8ew7IeAol/HczWyuAsVxENwXKfiQvqcMHM9MzUg+M+YLNZ/TsRPK5OtqYiI1kADGzQwAcRfKliQRQ4rlm9g4ABwP4ckLxK3f7V/XHzPQSoQeG3rT1l+NI7l3V9jD1kgDEzNYBcCWAuwBsQvKPwwTV5bpmtkS4tVk8wTivDVeT3w7im5nNCGANAJ8Kt1JvG6XeqwAWJ6lnn9ZLKoBcGB4uJcCtJJdtXYkMGjSz5cObpN6tR4pePx0gOX0058xsTgAbAPgkgFUAjLxajKx2Ask9YwUaHRAzWyq8a+/X4BqSa8YSJcV2zWx1AOcBmCNF/0bx6SwAh5F81Mz0HWbD8NpZkA9a7gOwMsmnBq1Q93kpAHICgC+NEtglJDerO+Ac7ZnZ+gDOBzBLZv7r+4lK1X72GZI/jBlzVcdr8Tm8sbgbwGxjGDyF5K61NJapETPTu//rMnV/GLfPILnjMAbqqBsbkG0AnD1OIHuQPLGOYHOzYWYzA/g5gNKeyR4AsBbJP8fOWWxA1PF3H0CENUjqDUlRxcy+DWCvooIGdFu2NMk7Uog7NiA3Axj0I9fGJC9LQbQ2fDAzPX9d1EZbibUxmeQvU/EpNiAvAhjt3fdY+uxM8rRUxGvKj/BsplurJsdUNeX+MHY3J3nxeAbMbF0AW5PU2LNGSzRAzOxjGkZdIboDSR5RoV42VczsFABfyMbhehw9gOSRY5kys7UB6G2enltn0sdFklfX0/TYVmICsimAcf+3GMP1k0nu1rQ4MeybmT4C6s3erDHaj9CmxlnpRcw5I9sOUAiMjQDM3ff3HUme0YavMQHZA8DxQwR5OYBdSNY+knQIn4auamYHAjh8aEN5GPgpgP1J3mVmK+vhHMCCYYKXPi6O9pX9bJIas9VKiQnINzWEecgodYu2F8mbhrSTRPUwdF1Xj48k4VCzThwGYLUAw3jDTXqePESy1eeymIBo2MSWNeRAo391/6pXolkXM9PcBw3R8DKKAiRb76+tN9iL28xuADC5xp6gAY8C5U812mzVlJnpW4/+V/UytQJLkbyzbWFiAqKxRVvUHLCGyQuSqON3qsRkZpMAPFSlbgF1oo2miAnIsQ1O+NHtlh7+sllcwMw2BnBpAZ19oiFeRFLz7KOUmIBoNpwgaar8CsDXSOqDW/LFzA4FoFmVXt5Q4EckN4kpSExAdHul26ymy0kAjib5WNMNDWPfzDSMRnMmvPxfgRNJ6lNA1BITED2g60G9jaJRoYLk5DYaq9KGmWnxg/mr1O1gnX1INnl3MbBkMQHRl+JnB/a0nhP1lkigJHXbZWazA4g2a64eaWuzEn2SVH8k0QCRE2b2+7A0Zm3qDmgoqdsuM9Pc7OsH9L3Lpy1P8paUAowNiD6K6eNYjKIhKj/QQfJ3MRzotemATFFi3hQmSI3sB7EB0YDD78TsnKHtCwIoV8XwpXBANFhxdpK9+esxUjBmm7EB0erjtyWkyI1h5RBdVZ5vy6+CAXlBE+Y0WLEtrSfaTlRAwnOIRnSmtsTPwwGUq9qY+lkwIA+Q1IqKyZYUANHKFSnPEtRIYd16CZZ7mshkwYBcRzLpsWcpAKJXnFogTCvupV60/I5g+QnJB+tytmBAriRZ1x4mdaXjTXaiAxJus/Ta9YuNRNic0Z+F5yftwHQjycp7ZRQMyMVtzCsfpgukAogmCGmFk7EWkBsmxjbqaj8/vWzQMWXrsokAUzAg55Lcuo0EVW0jCUDCVeQAAN+oGkiC9fRmRrdhGubypoOkFnh+vRQMyGkkd04wd6+7lBIgM4SriBaz7nr5T4Dm7yHQDwGYq+tBjxJf1JXbB9E7GUDCVUTj/jUz0EsZCgy16U4bEiUFSIBEt1m63fLSfQUOJanFG5ItyQESIBlrS4RkhXTHKimwO0m9wUy2JAlIgESjOktb1TzZjtKQY1uSbGPSXGX3owGiNaBI/ndanptZkgPYKqvtFUcqsDZJDTVKtsQERN89tA+EJi9dMdbgQDPTMj4fSFZBd2wYBZYhmdJg1aliiQnIvwG8PXik7wRXBFCm2gekgTW0hkmq161PgUkkNdU42RITkLFunzR5SbBo2997Sf4hPJPEnFyVbAIzd0zzQP6ZcgwxAdG6utoCYbzyGoD7w6FbMl8aZzzF8vi7kXxL6q7GBOR7AHZKXSD3rzEF7ia5eGPWazIcExDBIUi8lKnAeSS3Sj30mIBU3WEqdU3dv8EU2JfkMYOdGu+saICEB2/N+9Z2Wl7KUyD5byBKSWxAtJvpSuX1DY9Yo5dJPp66ErEB+RaAvVMXyf2rXYGnSA66q1TtjU/EYGxAVgCgVdi9lKXADSRXzSHkqICE55ArAayTg1juY20KJD/MvRdpCoB8NiwBWpv6bih5BSaT1PNn8iU6IOEqMuhX9eQFdQfHVeBZku8c96xETkgFEP9omEiHaMENrSmWzS11EoD4VaSFbplOE9o78qh03Jm2JykB4nuE59JrhvNzRZJazjWLkgwg4SriQ9qz6DaVnbyf5EKVa0eomBogmjmofQt9BmGEztBCk4eTPKiFdmprIilAwlVkMwAX1RahG0pJgSVj7+Y1UTGSA8QhmWgKszlf20esm423wdEkAQmQaM3WU3MT1P0dU4EdSJ6Zmz7JAhIgOdSn2ObWpUb1V6N2FyKp/QizKkkDEiD5KoCvZ6WqOztSgZNI7p6jLMkDEiDZEoCGxr8vR5HdZ2T17aM/X1kAEiBZDICmaK7uHS4rBbIaWjJS2WwA6TluZoLkK1l1kbKd3YrkeblKkB0g4WqiBR80wNGXDUq752kds0VIvpq2m2N7lyUgfVcTgaLXwdpK2kt6ChxMMusXLFkD0geKtjBbG8CGAFZJr58U6dELABYl+XDO0XcCkP4EmJl2zN0YwCYAlsg5OZn7/l2SuW3tPZXkWQBiZkeEAYzvBqANMJ8b8XMSgHkBvD8cmfet7N1/SpsfkXwo90hyAURvQfQtxEseCmT/7NGTORdA9GxxWR59o3gv7wtXD+3/kn3JAhCpbGbX+wN4Fv1tJ5KnZ+HpAE7mBIhWAj9ngJj8lHgKXEdytXjN199yNoCEq8jtAJaqXwa3WJMC65P8cU22kjCTGyCacNOpBCTRC+px4lSSu9RjKh0rWQESriJHAtgvHQndEwCPapV+ktqMtVMlR0DeCuA63zYhqX64M8nTkvKoJmeyAyRcRfQcoucRL/EVuJzkRvHdaMaDLAEJkGg4yaXNyOJWB1TgpXBrdduA52d3WraABEh8p9y4XS6bbQyqypQ1IAESLTQ3uaoAXq+yApeQ1BpmnS7ZAxIgORvANp3OVFrBPQhgTZJ6e9Xp0glAAiSHANAyQV6aV2A9ktoZrPOlM4AESPQ25VgA83c+c/ECzGr7gmFl6hQgAZIPhtVPOvvqcdikD1H/fJJFTTvoHCC95JuZHiB38w+KQ+Dw5qr3hOeOv9VmMQNDnQWkD5TPh8lW/qZruA6ph/JrhjORX+3OA9IHigDRVUXHe/NLVVSPNyd5cVQPIjVeDCB9oMwWVmfUKiifA6CxXV7GVqBYOCRJcYD09wMzmy7Aoh2t9HC/cDjmdmKmKFA0HMUDMhoEZrYFgBP8NszhcED6CDEzrRyv5YW296sHtiX5fdeh8FusvucSvdsXHFpXq/SyD0l9bPXizyC2OIA9AGiPdi+AwzGiFxT5kG5mCwDYNRzTOxlTFNiOpAZ9eulToChAzGyePjDe4T1higIGQKuRFDH4cKI5LwKQcMXYGsAOAOacqEgdPv8vADYl+ZsOxzhUaJ0GxMyWBSAwNFdkpqGU6l7lW/WhlOQj3Qutvog6B0j4+Kev5AKj8zPeKnYFzeXfnuSzFesXU60TgJjZrADW6Dv0ZdzL1Aq8AuBAkke7OIMpkC0gZqalf7QF2woBjDkGC7nYs24KcNxYrAIVAs8CEDPT5jjzAVgRwHIAlgTgQAyecH3405Xj5cGr+JlSoHFAzEz/w68E4PmwK5R2iNLeEfo5A4CZAcwSjt7vGiwoIHqHBhV6mbgCWlxBYPj6YRPXbkqNNgBRJ9dedbsHICq66tUmqMAZWsSC5F8nWM9P71OgcUB6bZnZJwIomoPhpTkFrgZwHMlrm2uiHMutAdIHygYA9vTF3mrvZHcDON6Hi9Sra+uA9IGyY/iyvUy9IRVn7R+6YgQ49JznpUYFogHSB4q2VtMQkJVrjKsEUy8AOCvcTj1cQsAxYowOSB8omwdQ9MHPy9gKaBfZC3WQdDAa7inJANIHyvoANO1VWz/P2HD8OZnX1nM9MF7LyfGcfU0OkD5QNFxEkOihvtQ1rZ4EcEG4WmhwoZeWFUgWkH4dwitigSJgFmxZo7ab0y2UtnTQcT3JZ9p2wNt7Q4EsABkBi64mOrQf9/IdSOarAqEPCJ+bkVBSswNkBCy6DVtVM+LCrVhC0k7TlTsB6LglXCUey8Xx0vzMGpCRyTIzfVNZGoB+6piUQEJfBKCRtDqmgEGyqAWgE8hBZRc6BcgowMweQBE0GgA5Vzj0u/5WV9FbJY15erzvp2bq3UTyjroacTvtK9BpQKYlp5lpCq6AESz6Xa+U9bN39P6tSUb6KNc7dEXo/f60oCD5RPup8xbbUKBYQNoQ19vIXwEHJP8cegQNKuCANCium85fAQck/xx6BA0q4IA0KK6bzl8BByT/HHoEDSrggDQorpvOXwEHJP8cegQNKuCANCium85fAQck/xx6BA0q4IA0KK6bzl8BByT/HHoEDSrggDQorpvOXwEHJP8cegQNKuCANCium85fAQck/xx6BA0q4IA0KK6bzl8BByT/HHoEDSrggDQorpvOXwEHJP8cegQNKuCANCium85fAQck/xx6BA0q4IA0KK6bzl8BByT/HHoEDSrggDQorpvOXwEHJP8cegQNKuCANCium85fAQck/xx6BA0q4IA0KK6bzl8BByT/HHoEDSrggDQorpvOXwEHJP8cegQNKuCANCium85fAQck/xx6BA0q4IA0KK6bzl8BByT/HHoEDSrggDQorpvOXwEHJP8cegQNKvA/Lj3i9ip3JnEAAAAASUVORK5CYII="
        },
        356: function(e, t, a) {
            e.exports = a(812)
        },
        361: function(e, t, a) {},
        364: function(e, t, a) {},
        367: function(e, t, a) {},
        368: function(e) {
            e.exports = {
                abi: [{
                    inputs: [{
                        internalType: "address",
                        name: "_feeToSetter",
                        type: "address"
                    }],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "constructor"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !0,
                        internalType: "address",
                        name: "token0",
                        type: "address"
                    }, {
                        indexed: !0,
                        internalType: "address",
                        name: "token1",
                        type: "address"
                    }, {
                        indexed: !1,
                        internalType: "address",
                        name: "pair",
                        type: "address"
                    }, {
                        indexed: !1,
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    name: "PairCreated",
                    type: "event"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "INIT_CODE_PAIR_HASH",
                    outputs: [{
                        internalType: "bytes32",
                        name: "",
                        type: "bytes32"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    name: "allPairs",
                    outputs: [{
                        internalType: "address",
                        name: "",
                        type: "address"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "allPairsLength",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !1,
                    inputs: [{
                        internalType: "address",
                        name: "tokenA",
                        type: "address"
                    }, {
                        internalType: "address",
                        name: "tokenB",
                        type: "address"
                    }],
                    name: "createPair",
                    outputs: [{
                        internalType: "address",
                        name: "pair",
                        type: "address"
                    }],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "feeTo",
                    outputs: [{
                        internalType: "address",
                        name: "",
                        type: "address"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "feeToSetter",
                    outputs: [{
                        internalType: "address",
                        name: "",
                        type: "address"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        internalType: "address",
                        name: "",
                        type: "address"
                    }, {
                        internalType: "address",
                        name: "",
                        type: "address"
                    }],
                    name: "getPair",
                    outputs: [{
                        internalType: "address",
                        name: "",
                        type: "address"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !1,
                    inputs: [{
                        internalType: "address",
                        name: "_feeTo",
                        type: "address"
                    }],
                    name: "setFeeTo",
                    outputs: [],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    constant: !1,
                    inputs: [{
                        internalType: "address",
                        name: "_feeToSetter",
                        type: "address"
                    }],
                    name: "setFeeToSetter",
                    outputs: [],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }]
            }
        },
        369: function(e) {
            e.exports = [{
                constant: !0,
                inputs: [{
                    components: [{
                        name: "target",
                        type: "address"
                    }, {
                        name: "callData",
                        type: "bytes"
                    }],
                    name: "calls",
                    type: "tuple[]"
                }],
                name: "aggregate",
                outputs: [{
                    name: "blockNumber",
                    type: "uint256"
                }, {
                    name: "returnData",
                    type: "bytes[]"
                }],
                payable: !1,
                stateMutability: "view",
                type: "function"
            }, {
                constant: !0,
                inputs: [{
                    name: "addr",
                    type: "address"
                }],
                name: "getEthBalance",
                outputs: [{
                    name: "balance",
                    type: "uint256"
                }],
                payable: !1,
                stateMutability: "view",
                type: "function"
            }]
        },
        370: function(e) {
            e.exports = {
                address: "0x9f3cE6C7dE4F9274e69e23442936dd23B97B2237",
                abi: [{
                    constant: !0,
                    inputs: [],
                    name: "getMyMiners",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "getBalance",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "initialized",
                    outputs: [{
                        name: "",
                        type: "bool"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        name: "rt",
                        type: "uint256"
                    }, {
                        name: "rs",
                        type: "uint256"
                    }, {
                        name: "bs",
                        type: "uint256"
                    }],
                    name: "calculateTrade",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        name: "eth",
                        type: "uint256"
                    }, {
                        name: "contractBalance",
                        type: "uint256"
                    }],
                    name: "calculateEggBuy",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "marketEggs",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !1,
                    inputs: [],
                    name: "sellEggs",
                    outputs: [],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        name: "amount",
                        type: "uint256"
                    }],
                    name: "devFee",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "pure",
                    type: "function"
                }, {
                    constant: !1,
                    inputs: [],
                    name: "seedMarket",
                    outputs: [],
                    payable: !0,
                    stateMutability: "payable",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "getMyEggs",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        name: "",
                        type: "address"
                    }],
                    name: "lastHatch",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        name: "",
                        type: "address"
                    }],
                    name: "claimedEggs",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        name: "",
                        type: "address"
                    }],
                    name: "hatcheryMiners",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "EGGS_TO_HATCH_1MINERS",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        name: "eth",
                        type: "uint256"
                    }],
                    name: "calculateEggBuySimple",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        name: "amount",
                        type: "uint256"
                    }],
                    name: "calcMinerBuy",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        name: "eggs",
                        type: "uint256"
                    }],
                    name: "calculateEggSell",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        name: "",
                        type: "address"
                    }],
                    name: "referrals",
                    outputs: [{
                        name: "",
                        type: "address"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "marketMiners",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        name: "",
                        type: "address"
                    }],
                    name: "referralData",
                    outputs: [{
                        name: "affFrom",
                        type: "address"
                    }, {
                        name: "tierInvest1Sum",
                        type: "uint256"
                    }, {
                        name: "tierInvest2Sum",
                        type: "uint256"
                    }, {
                        name: "tierInvest3Sum",
                        type: "uint256"
                    }, {
                        name: "affCount1Sum",
                        type: "uint256"
                    }, {
                        name: "affCount2Sum",
                        type: "uint256"
                    }, {
                        name: "affCount3Sum",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        name: "adr",
                        type: "address"
                    }],
                    name: "getEggsSinceLastHatch",
                    outputs: [{
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !1,
                    inputs: [{
                        name: "ref",
                        type: "address"
                    }],
                    name: "buyEggs",
                    outputs: [],
                    payable: !0,
                    stateMutability: "payable",
                    type: "function"
                }, {
                    constant: !1,
                    inputs: [{
                        name: "ref",
                        type: "address"
                    }, {
                        name: "amount",
                        type: "uint256"
                    }],
                    name: "hatchEggs",
                    outputs: [],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "constructor"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !0,
                        name: "who",
                        type: "address"
                    }, {
                        indexed: !1,
                        name: "minerBought",
                        type: "uint256"
                    }],
                    name: "Buy",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !0,
                        name: "who",
                        type: "address"
                    }, {
                        indexed: !1,
                        name: "eggSold",
                        type: "uint256"
                    }, {
                        indexed: !1,
                        name: "tokenEarned",
                        type: "uint256"
                    }],
                    name: "Sell",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !0,
                        name: "who",
                        type: "address"
                    }, {
                        indexed: !1,
                        name: "rewards",
                        type: "uint256"
                    }, {
                        indexed: !1,
                        name: "minerBought",
                        type: "uint256"
                    }],
                    name: "Compound",
                    type: "event"
                }]
            }
        },
        371: function(e) {
            e.exports = {
                abi: [{
                    constant: !1,
                    inputs: [{
                        internalType: "address",
                        name: "_minter",
                        type: "address"
                    }],
                    name: "addMinter",
                    outputs: [],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "constructor"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !0,
                        internalType: "address",
                        name: "owner",
                        type: "address"
                    }, {
                        indexed: !0,
                        internalType: "address",
                        name: "spender",
                        type: "address"
                    }, {
                        indexed: !1,
                        internalType: "uint256",
                        name: "value",
                        type: "uint256"
                    }],
                    name: "Approval",
                    type: "event"
                }, {
                    constant: !1,
                    inputs: [{
                        internalType: "address",
                        name: "spender",
                        type: "address"
                    }, {
                        internalType: "uint256",
                        name: "amount",
                        type: "uint256"
                    }],
                    name: "approve",
                    outputs: [{
                        internalType: "bool",
                        name: "",
                        type: "bool"
                    }],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    constant: !1,
                    inputs: [{
                        internalType: "address",
                        name: "spender",
                        type: "address"
                    }, {
                        internalType: "uint256",
                        name: "subtractedValue",
                        type: "uint256"
                    }],
                    name: "decreaseAllowance",
                    outputs: [{
                        internalType: "bool",
                        name: "",
                        type: "bool"
                    }],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    constant: !1,
                    inputs: [{
                        internalType: "address",
                        name: "spender",
                        type: "address"
                    }, {
                        internalType: "uint256",
                        name: "addedValue",
                        type: "uint256"
                    }],
                    name: "increaseAllowance",
                    outputs: [{
                        internalType: "bool",
                        name: "",
                        type: "bool"
                    }],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    constant: !1,
                    inputs: [{
                        internalType: "address",
                        name: "account",
                        type: "address"
                    }, {
                        internalType: "uint256",
                        name: "amount",
                        type: "uint256"
                    }],
                    name: "mint",
                    outputs: [],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    constant: !1,
                    inputs: [{
                        internalType: "address",
                        name: "_minter",
                        type: "address"
                    }],
                    name: "removeMinter",
                    outputs: [],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    constant: !1,
                    inputs: [{
                        internalType: "address",
                        name: "_governance",
                        type: "address"
                    }],
                    name: "setGovernance",
                    outputs: [],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    constant: !1,
                    inputs: [{
                        internalType: "address",
                        name: "recipient",
                        type: "address"
                    }, {
                        internalType: "uint256",
                        name: "amount",
                        type: "uint256"
                    }],
                    name: "transfer",
                    outputs: [{
                        internalType: "bool",
                        name: "",
                        type: "bool"
                    }],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !0,
                        internalType: "address",
                        name: "from",
                        type: "address"
                    }, {
                        indexed: !0,
                        internalType: "address",
                        name: "to",
                        type: "address"
                    }, {
                        indexed: !1,
                        internalType: "uint256",
                        name: "value",
                        type: "uint256"
                    }],
                    name: "Transfer",
                    type: "event"
                }, {
                    constant: !1,
                    inputs: [{
                        internalType: "address",
                        name: "sender",
                        type: "address"
                    }, {
                        internalType: "address",
                        name: "recipient",
                        type: "address"
                    }, {
                        internalType: "uint256",
                        name: "amount",
                        type: "uint256"
                    }],
                    name: "transferFrom",
                    outputs: [{
                        internalType: "bool",
                        name: "",
                        type: "bool"
                    }],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        internalType: "address",
                        name: "owner",
                        type: "address"
                    }, {
                        internalType: "address",
                        name: "spender",
                        type: "address"
                    }],
                    name: "allowance",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        internalType: "address",
                        name: "account",
                        type: "address"
                    }],
                    name: "balanceOf",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "decimals",
                    outputs: [{
                        internalType: "uint8",
                        name: "",
                        type: "uint8"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "governance",
                    outputs: [{
                        internalType: "address",
                        name: "",
                        type: "address"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "maxSupply",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [{
                        internalType: "address",
                        name: "",
                        type: "address"
                    }],
                    name: "minters",
                    outputs: [{
                        internalType: "bool",
                        name: "",
                        type: "bool"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "name",
                    outputs: [{
                        internalType: "string",
                        name: "",
                        type: "string"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "symbol",
                    outputs: [{
                        internalType: "string",
                        name: "",
                        type: "string"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }, {
                    constant: !0,
                    inputs: [],
                    name: "totalSupply",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }]
            }
        },
        372: function(e, t) {},
        373: function(e, t, a) {},
        421: function(e, t, a) {
            e.exports = a.p + "static/media/twitter1.png"
        },
        431: function(e, t, a) {
            e.exports = a.p + "static/media/twitter1.png"
        },
        432: function(e, t, a) {},
        436: function(e, t, a) {},
        437: function(e) {
            e.exports = {
                header: {
                    home: "Home",
                    exchange: "Exchange",
                    guide: "Guide",
                    backup: "Backup Site",
                    vault: "Vault"
                },
                faq: {
                    faq: "FAQ",
                    q1: "Sustainability",
                    a1: "Unlike other ROI projects which will eventually run out of funds and drain the contract, VIPMiner invented a unique algorithm to generates stable daily cash flow for investors through VIPMiner trading fees by simply holding miners. Miners can be bought and sold at anytime through the VIPMiner smart contract and investors will receive huge capital gains.",
                    q2: "Verified Public Contract",
                    a2: "The VIPMiner contract is public, verified and can be viewed here on BSCScan.",
                    q3: "Audit Report",
                    a3: "The VIPMiner contract is professionally audited and found NO backdoors and NO rugpull functions, audit report can be viewed here.",
                    q4: "Miner Info",
                    a4: "VIPMiner taxes 15% trading fees for buying and selling miners and the fees are instantly distributed to all miners in the form of BNB. The more miners you hold means the higher mining power you have, therefore the more BNB you can mine. ",
                    a41: "VIPMiner pays 5%~25% daily based on the trading volume of miners, and your miners will appreciate overtime and you can always cash out by selling.",
                    a42: "The object of the game is buying and compounding more miners, sooner and more often than other players. This in turn earns you more BNB faster. Compounding miners using your daily BNB earnings will increase your miner amount and mining power therefore to earn you more BNB day by day.",
                    q5: "What makes VIPMiner so special?",
                    a5: "Holding onto Miners means you are continuously mining free BNB every single time any other users buys, sells or transfers Miners. Many holders often report earnings between 5%-25% of their holdings on a daily basis, though this fluctuates heavily based on transaction volume."
                },
                claim: {
                    claim: "Claim",
                    claim1: 'Any individual (the "user") understands and accepts that crypto assets do not necessarily have a specific form of protection or regulation by any governmental body. The value of these crypto assets is highly volatile and speculative, extending the possibility of total loss.',
                    claim2: "You further represent and warrant that you:",
                    claim3: "a. are at least 18 years old or of other legal age, according to your relevant jurisdiction;",
                    claim4: "b. guarantee that your crypto assets, which you transfer to the VipMiner smart contract are not encumbered, not in contention, or under seizure, and that neither exist any rights of third parties to your crypto assets;",
                    claim5: "c. will not use our Services or will immediately cease using those if any applicable law in your country prohibits or will prohibit you at any time from doing so;"
                },
                homePage: {
                    slogen: "The Ultimate Autonomous Yield Earning Miner Market",
                    note: "VipMiner are meant to generate you BNB dividends continuously every single time any other member of the hire or sell miners.",
                    exchangeCxx: "Enter Exchange",
                    visitExchange: "Visit Exchange",
                    whitepaper: "Whitepaper",
                    audit: "Audit Report",
                    verifiedContract: "Verified Contract",
                    contractAddress: "Contract Address",
                    copy: "Copy",
                    holders: "Holders",
                    marketcap: "Market Cap",
                    price: "Price",
                    totalSupply: "Total Supply",
                    timeLeft: "Saturday Nov 2 2019 14:00:00 UTC",
                    highestBuy: "Highest 33% Buy And Sell Dividends ",
                    highestRef: "Highest 10% Referral Commissions ",
                    dailyInt: "2% Daily Interests",
                    releaseIn: "VipMiner Launching In ",
                    days: "Days",
                    hours: "Hours",
                    minutes: "Mins",
                    balance: "Balance: ",
                    seconds: "Secs",
                    code1: "View Open Source Code",
                    code2: "View Verified Contract",
                    secondOne: "Our Exchange takes away the hard part of crypto dividends",
                    secondTwo: "The Comet Protocol pays VipMiner holders 20% dividends through total trading volume. Holders receive their BNB dividends proportionally and instantly, relative to the total VipMiner circulating supply.",
                    thirdOneOne: "Hold BNB",
                    thirdOneTwo: "Send to a Web 3.0 wallet like MetaMask or Trust Wallet",
                    thirdTwoOne: "Purchase VipMiner",
                    thirdTwoTwo: "You will receive VipMiner for BNB and pay the 10% dividends fee to all token holders.",
                    thirdThreeOne: "Earn Dividends",
                    thirdThreeTwo: "Any new buy or sell will trigger you to receive dividend in your earnings.",
                    thirdFourOne: "Reinvest Dividends",
                    thirdFourTwo: "Reinvest BNB dividends for more VipMiner Miners and increase your overall percentage of the supply.",
                    thirdFiveOne: "Withdraw Dividends",
                    thirdFiveTwo: "Withdraw BNB directly to your wallet, the Smart Contract does the hard part.",
                    thirdSixOne: "Earn Consistent BNB",
                    thirdSixTwo: "All dividends are paid in BNB only. Simple and transparent.",
                    fourthOne: "VIPMiner: Investors can hire and sell miners freely",
                    fourthTwo: "Through the smart contract and earn 5% ~ 25% daily cash flow from the miner trading fees."
                },
                notification: {
                    transactionSuccess: "Transaction send, please allow up to 10s for confirmation.",
                    transactionCompelted: "Transaction Confirmed!",
                    transactionFailed: "Transaction failed, please send the transaction again.",
                    loginPrompt: "Please login to your BSC wallet",
                    investSuccess: " just staked ",
                    insufficientUnstakedAmount: "Insufficient Unstaked Amount",
                    insufficientEthBalance: "Insufficient BNB Balance",
                    invalidBuyAmount: "Invalid Buy Amount",
                    invalidSellAmount: "Sell Amount cannot be less than 1 VipMiner",
                    insufficientDividendsBalance: "Insufficient Dividends",
                    insufficientProfit: "Insufficient Profit",
                    comingSoon: "Coming Soon!",
                    buyEvent: "Token Purchase",
                    invested: "invested",
                    justNow: "Just now!",
                    noWallet: "Please login to your wallet!",
                    minDeposit: "Minimum deposit is 0.01 BNB",
                    needGasFee: "You need a few (0.01) BNB in your wallet to make an transaction",
                    insufficientBalance: "Insufficient Balance",
                    successWithdraw: "Withdraw success",
                    successBuy: "Stake success",
                    depositEvent: "Vault Stake",
                    staked: "staked",
                    plan0: "for 188 days",
                    plan1: "for 92 days",
                    plan2: "for 51 days",
                    plan3: "for 25 days"
                },
                investSection: {
                    buyDiamond: "Hire Miners ",
                    percentDivBuy: "15% Dividend Distribution",
                    availableBuy: "Available:",
                    buyPrice: "Miner Price",
                    buyAmount: "Hire Amount",
                    cXXAmount: "Diamond Amount",
                    buyToken: "Hire Miners",
                    yourTotal: "Your Total Dividends",
                    reinvest: "Reinvest Dividends",
                    withdraw: "Withdraw Dividends",
                    sellDiamond: "Sell Miners ",
                    percentDivsell: "15% Dividend Distribution",
                    availableSell: "Available:",
                    sellPrice: "Miner Price",
                    sellAmount: "Sell Amount",
                    eTHAmount: "BNB Amount",
                    sellToken: "Sell Miners",
                    balance: "Balance: ",
                    reinvestValue: "Miners Amount",
                    max: "MAX",
                    youWillGet: "You will get approximately ",
                    reinvestPrompt: "Reinvest your BNB dividends to get this amount of Miners"
                },
                exchangeTop: {
                    yourCxxToken: "Your Miners",
                    yourDividendEarn: "Your Dividend Earnings",
                    yourReferralEarn: "Your Referral Earnings",
                    circulatingSupply: "Circulating Supply",
                    contractCap: "Contract Balance",
                    volume: "Total Trading Volume",
                    totalDividends: "Total Exchange Dividends",
                    value: "Value"
                },
                referral: {
                    title: "Referral Bonus",
                    status: "Referral Status",
                    copySuccess: "Copied to Clipboard",
                    copy: "Copy",
                    tier1: "Tier1",
                    tier2: "Tier2",
                    tier3: "Tier3",
                    reward: "Reward",
                    referrals: "Total Referrals:",
                    threeTierProgram: "3 Tier Mega Referral Program",
                    totalRewards: "Total Rewards:",
                    totalInvested: "Total Invested:",
                    inviteLink: "Your Referral Link",
                    note: "Your Tier 1 referral masternode is auto activated when you connected to your wallet. You need 100 miners to activate your referral masternodes"
                },
                vault: {
                    nodeHomepage: {
                        slogen1: "CometVault is the first secure and passive earning aggregator in the Comet ecosystem.",
                        launchSoon: "Launch Soon",
                        businessPlan: "Whitepaper",
                        launch: "Launching in",
                        telegram: "Telegram",
                        contract: "VERIFIED CONTRACT",
                        audit: "Audit",
                        totalInvested: "Total Staked",
                        yourWallet: "Your Wallet: ",
                        yourWalletBalance: "Your Wallet Balance: ",
                        nodeDividends: "Dividends Pool",
                        insurancePool: "Insurance Fund"
                    },
                    planCard: {
                        earthNode: "Comet Plan",
                        marsNode: "Earth Plan",
                        jupiterNode: "Mars Plan",
                        venusNode: "Sun Plan",
                        divEverySec: "Dividends every second",
                        forever: "Forever ",
                        days: " day",
                        period: "Mining period ",
                        totalReturn: "Total return ",
                        minInvest: "Min. stake is ",
                        placeholder: "Amount of BNB",
                        invest: "Stake"
                    },
                    withdrawSection: {
                        dividends: "Dividends",
                        refRewards: "Referral rewards",
                        withdrawable: "Withdrawable (Divs + Refs)",
                        withdraw: "Withdraw",
                        transacFeeNote: "You should have 0.1-0.2 BNB for the transaction fee",
                        myTotalInvest: "My total staked ",
                        myTotalDiv: "Total dividends so far ",
                        referral: "Referral",
                        refLink: "Referral Link ",
                        copyButton: "Copy",
                        copySuccess: "Copied to Clipboard",
                        copy: "Copy",
                        downlineDeposits: "All Downline Staked: ",
                        bonusNote: "0.1% hold bonus if don\u2019t withdraw, the bonus can be accumulated daily.",
                        tier1: "Tier 1 (5% Referral rewards) ",
                        tier2: "Tier 2 (3% Referral rewards) ",
                        tier3: "Tier 3 (2% Referral rewards) ",
                        tier4to10: "Tier4-10 (1% Referral rewards) ",
                        invitee: "Invitee (0.5% of the investment)",
                        referrals: "referrals",
                        totalRefRewards: "Total referral payout : ",
                        earned: "Dividends Earned ",
                        cancel: "Cancel",
                        curRate: "Current Withdraw Rate",
                        afterTaxReward: "You will received",
                        harvest: "Withdraw",
                        holdBonus: "0.1% hold bonus if don\u2019t withdraw, the bonus can be accumulated daily."
                    },
                    investments: {
                        myInvestments: "My Investments",
                        plan0: "2.2% Daily ROI",
                        plan1: "3.3% Daily ROI",
                        plan2: "4.1% Daily ROI",
                        plan3: "5.6% Daily ROI",
                        payout: "Payout",
                        invested: "Staked",
                        withdrawable: "Withdrawable",
                        countdown: "Countdown"
                    },
                    faq: {
                        noteTitle1: "Sustainability",
                        note1: "Heco Node runs automatically on the blockchain and its smart contract is uploaded to the HECO blockchain. No one is able to edit or delete the smart contract, nor influence its autonomous operation. The dividends are also automatically paid through the smart contract.",
                        noteTitle2: "Dividend distribute",
                        note2: "Heco Node smart contract generates 3.5% - 8% dividends per day based on your investment and distribute your dividends to your balance. For example, if you invest in the 8% plan, then you will get over 100% of your first deposit in less than 12.5 days. The dividends generate every second and you can withdraw or reinvest your dividends each second. When you reinvest, the total investment would increase and you will get more dividends. 0.5% hold bonus if don\u2019t withdraw, the bonus can be accumulated daily. ",
                        noteTitle3: "Referral program",
                        note3: "Heco Node smart contract set 10 tiers of referral rewards, which are 4%, 3%, and 1%, 1%, 1%, 1%, 1%, 1%,1% respectively. The referral rewards are distributed to your balance automatically and you can withdraw at anytime.",
                        q1: "How to invest on desktop?",
                        a11: "You can install the ",
                        a1_tronlink: "Metamask",
                        a12: "",
                        a1_tronpay: "",
                        a13: " extension on Chrome. After the installation, you can create a new BNB wallet or import an existing BNB wallet, and then transfer the BNB from the exchange to the wallet. Finally, login on Metamask to browse this website and invest.",
                        q2: "How to invest on mobile?",
                        a21: "You can download ",
                        a2_tronLinkPro: "Huobi wallet",
                        a22: " , ",
                        a2_tokenPocket: "TokenPocket",
                        a2_dappBirds: "",
                        a23: " or ",
                        a2_tronWallet: "Bitkeep",
                        a24: " app from application store. After the installation, you can create a new BNB wallet or import an existing BNB wallet, and then transfer the BNB from the exchange to the wallet. Finally, find HuobiEco within the wallet app or browse our site with the browser in the app, and then go to invest or withdraw.",
                        q3: "How is the fund distributed?",
                        a3: "Technical support: 1% Marketing: 2% Referral: 6%-4%-2% Invitee: 0.5% JustSwap liquidity provide: 15%",
                        q4: "What is the referral program?",
                        a4: "HecoEco smart contract set 3 tiers of referral rewards, which are 4%, 3%, and 1%,  1%, 1%,1%,1%,1%,1% respectively. The referral rewards are distributed to your balance automatically and you can withdraw at anytime.",
                        q5: "What is the hold bonus?",
                        a5: "The Heco Node smart contract has created a unique hold bonus mechanism. Miners can get a 0.5% hold bonus add to their base rate per day if they do not withdraw their profits. The hold bonus can be accumulated every day. When the miner withdraws, the calculation power bonus will be reset, and the basic rate remains unchanged."
                    }
                }
            }
        },
        438: function(e) {
            e.exports = {
                header: {
                    home: "\u9996\u9875",
                    exchange: "\u4ea4\u6613\u6240",
                    guide: "\u5e2e\u52a9\u4e2d\u5fc3",
                    backup: "\u5907\u7528\u7f51\u7ad9",
                    vault: "\u91d1\u5e93"
                },
                faq: {
                    faq: "\u5e38\u89c1\u95ee\u9898",
                    q1: "\u662f\u4ec0\u4e48\u4f7f VipMiner \u4ee3\u5e01\u5982\u6b64\u7279\u522b?",
                    a1: "\u6301\u6709 VipMiner \u4ee3\u5e01\u610f\u5473\u7740\uff0c\u4ea4\u6613\u6240\u7684\u4efb\u4f55\u5176\u4ed6\u7528\u6237\u6bcf\u6b21\u8d2d\u4e70\uff0c\u51fa\u552e\u6216\u8f6c\u8ba9 VipMiner \u4ee3\u5e01\u65f6\uff0c\u90fd\u4f1a\u4e0d\u65ad\u5411\u60a8\u5206\u53d1\u201c\u514d\u8d39\u201d BNB\u3002\u8bb8\u591a\u6301\u6709\u4eba\u62a5\u544a\u4ed6\u4eec\u6bcf\u5929\u7684\u6536\u76ca\u5728\u6240\u6301\u80a1\u4efd\u76840.5\uff05-10\uff05\u4e4b\u95f4\uff0c\u5c3d\u7ba1\u6536\u76ca\u4f1a\u6839\u636e\u4ea4\u6613\u91cf\u800c\u5927\u5e45\u6ce2\u52a8\u3002",
                    q2: "\u5408\u7ea6\u4f1a\u88ab\u6e05\u7a7a\u6216\u662f\u5b58\u5728\u9a97\u5c40\u5417?",
                    a2: "\u6211\u4eec 100% \u590d\u523b\u4e86\u8457\u540d\u7684 POWH3D \u7684\u5408\u7ea6\u4ee3\u7801\uff0c\u8be5\u4ee3\u7801\u5728\u8fc7\u53bb2\u5e74\u5185\u4e00\u76f4\u88ab\u8ba4\u4e3a\u662f\u5b89\u5168\u53ef\u9760\u7684\u3002\u60a8\u6295\u5165\u7684 BNB \u4e0d\u88ab\u4efb\u4f55\u4e2a\u4eba\u6216\u56e2\u4f53\u6301\u6709\u3002\u4ea4\u6613\u6240\u4e2d\u7684BNB\u4ec5\u7531\u5f00\u6e90\u7684\u5e01\u5b89\u94fe\u667a\u80fd\u5408\u7ea6\u5904\u7406\u3002",
                    q3: "VipMiner\u4ea4\u6613\u6240\u8fd8\u6709\u54ea\u4e9b\u98ce\u9669?",
                    a3: "\u6211\u4eec\u65e0\u6cd5\u5bf9\u4f60\u7684\u6295\u8d44\u505a\u51fa\u4fdd\u8bc1\uff0c\u5728\u52a0\u5bc6\u8d27\u5e01\u4e2d\u4e5f\u662f\u5982\u6b64\u3002\u9ed1\u5ba2\u653b\u51fb\uff0c\u505c\u6ede\u6216\u6050\u614c\u6027\u629b\u552e\u53ef\u80fd\u90fd\u662f\u4e3b\u8981\u7684\u98ce\u9669\u56e0\u7d20\u3002",
                    q4: "\u6211\u53ef\u4ee5\u76f4\u63a5\u4ece\u4ea4\u6613\u6240\u53d1\u9001 BNB \u5417\uff1f",
                    a4: "\u8bf7\u52ff\u4f7f\u7528\u4ea4\u6613\u6240\uff0c\u5426\u5219\u60a8\u53ef\u80fd\u4f1a\u635f\u5931\u6240\u6709\u5b58\u6b3e\u3002\u9996\u5148\u5c06\u5176\u8f6c\u79fb\u5230BNB\u94b1\u5305\u3002\u5728\u7535\u8111\u6216\u624b\u673a\u4e0a\u4f7f\u7528 Metamask, Coinbase, Trust Wallet\u3002",
                    q5: "\u4e3a\u4ec0\u4e48\u6211\u6ca1\u6709\u6536\u5230\u4ee3\u5e01\uff1f\u4e3a\u4ec0\u4e48\u6211\u7684\u4ea4\u6613\u4ecd\u5728\u8fdb\u884c\u4e2d?",
                    a5: "\u533a\u5757\u94fe\u4ea4\u6613\u53ef\u80fd\u9700\u8981\u51e0\u5206\u949f\u7684\u65f6\u95f4\u3002\u5982\u679c\u60c5\u51b5\u4ecd\u672a\u80fd\u88ab\u89e3\u51b3\uff0c\u8bf7\u5c1d\u8bd5\u589e\u52a0\u4ea4\u6613\u7684\u71c3\u6c14\u9650\u5236\u3002",
                    q6: "\u4e3a\u4ec0\u4e48 VipMiner \u4ee3\u5e01\u7684\u4e70\u5165\u4ef7\u683c\u4e0e\u5356\u51fa\u4ef7\u683c\u4e0d\u540c\uff1f",
                    a6: "\u4ea4\u6613\u6240\u7684\u673a\u5236\u5305\u62ec10\uff05\u7684\u4e70\u5165\u7a0e\u7387\u4ee5\u53ca10%\u7684\u5356\u51fa\u7a0e\u7387\uff0c\u5728\u7b7e\u8ba2 VipMiner \u4ea4\u6613\u6240\u5408\u7ea6\u65f6\uff0c\u60a8\u5c06\u652f\u4ed8\u7ea6\u4e3a20\uff05\u7684\u7a0e\u7387\u3002",
                    q7: "VipMiner \u4ee3\u5e01\u4ef7\u683c\u5982\u4f55\u8ba1\u7b97?",
                    a7: "\u8bf7\u6ce8\u610f\uff0c\u4e70\u5165\u65f6\u60a8\u4ec5\u9700\u7f34\u7eb310\uff05\u7684\u7a0e\uff0c\u4f4620\uff05\u7684\u603b\u7a0e\u4f1a\u5728\u60a8\u7684\u6301\u6709\u8d44\u4ea7\u4e2d\u663e\u793a\u3002",
                    q8: "\u4e3a\u4ec0\u4e48\u6211\u7684 VipMiner \u4ee3\u5e01\u6216 USDT \u4ef7\u503c\u65e0\u6cd5\u518d\u4ea4\u6613\u6240\u7f51\u7ad9\u4e0a\u663e\u793a?",
                    a8: "\u8bf7\u786e\u4fdd\u60a8\u5df2\u767b\u5f55 Metamask\uff0c\u5e76\u5173\u95ed\u4e86\u4efb\u4f55\u53ef\u80fd\u5e72\u6270\u4ea4\u6613\u6240\u7684\u5e7f\u544a\u62e6\u622a\u5668\u3002\u5982\u679c\u60a8\u6709\u591a\u4e2a\u94b1\u5305\uff0c\u8bf7\u786e\u4fdd\u60a8\u767b\u5f55\u4e86\u6b63\u786e\u7684\u5730\u5740\u3002",
                    q9: "\u6211\u4eec\u5982\u4f55\u5b9a\u4ef7 VipMiner\uff1f",
                    a9: "\u786c\u7f16\u7801\u5408\u7ea6\uff0c\u6bcf\u6b21\u4e70\u5356\u5c06\u4f7fVipMiner\u4ef7\u683c\u589e\u52a0/\u51cf\u5c11.00000001 BNB"
                },
                claim: {
                    claim: "\u58f0\u660e",
                    claim1: "\u7528\u6237\u9700\u4e86\u89e3\u52a0\u5bc6\u8d44\u4ea7\u4e0d\u53d7\u4efb\u4f55\u6cd5\u5f8b\u89c4\u5b9a\u4fdd\u62a4\u3002\u52a0\u5bc6\u8d44\u4ea7\u7684\u4ef7\u503c\u6ce2\u52a8\u6027\u6781\u5927\u4e14\u5177\u6709\u6295\u673a\u6027\u8d28\uff0c\u4ece\u800c\u589e\u52a0\u4e86\u7528\u6237\u635f\u5931\u7684\u53ef\u80fd\u6027.",
                    claim2: "\u7528\u6237\u9700\u58f0\u660e\u5e76\u4e14\u4fdd\u8bc1\uff1a",
                    claim3: "a. \u5728\u76f8\u5bf9\u7684\u6cd5\u5f8b\u7ba1\u8f96\u8303\u56f4\u5185\uff0c\u4f60\u5e74\u6ee118\u5c81\u6216\u4ee5\u4e0a",
                    claim4: "b. \u4f60\u9700\u786e\u4fdd\u8f6c\u5165 VipMiner \u667a\u80fd\u5408\u7ea6\u7684\u52a0\u5bc6\u8d44\u4ea7\u4e0d\u53d7\u4efb\u4f55\u963b\u788d\uff0c\u4e0d\u88ab\u5f81\u7528\uff0c\u4e0d\u88ab\u6ca1\u6536\u4e14\u4e0d\u5b58\u5728\u7b2c\u4e09\u65b9\u5bf9\u4f60\u52a0\u5bc6\u8d44\u4ea7\u7684\u6743\u5229;",
                    claim5: "c. \u5982\u679c\u60a8\u6240\u5728\u56fd\u5bb6/\u5730\u533a\u7684\u4efb\u4f55\u9002\u7528\u6cd5\u5f8b\u7981\u6b62\u60a8\u4f7f\u7528\u6211\u4eec\u7684\u670d\u52a1\uff0c\u4f60\u5c06\u505c\u6b62\u4f7f\u7528\u6216\u7acb\u5373\u505c\u6b62\u4f7f\u7528\u8fd9\u4e9b\u670d\u52a1."
                },
                homePage: {
                    slogen: "\u7ec8\u6781\u81ea\u4e3b\u6536\u76ca\u751f\u6210\u534f\u8bae",
                    note: "VipMiner\u4ee4\u724c\u4e3a\u6536\u76ca\u800c\u751f\uff0c\u6bcf\u5f53\u4ea4\u6613\u6240\u7684\u4efb\u4f55\u5176\u4ed6\u6210\u5458\u6bcf\u6b21\u8d2d\u4e70\uff0c\u51fa\u552e\u6216\u8f6c\u8ba9VipMiner\u4ee4\u724c\u65f6\u81ea\u52a8\u8fde\u7eed\u4e0d\u65ad\u5730\u4e3a\u60a8\u5e26\u6765BNB\u5206\u7ea2\u6536\u76ca\u3002",
                    exchangeCxx: "VipMiner\u4ea4\u6613\u6240",
                    visitExchange: "\u8fdb\u5165\u4ea4\u6613\u6240",
                    whitepaper: "\u767d\u76ae\u4e66",
                    audit: "\u5ba1\u8ba1\u62a5\u544a",
                    verifiedContract: "\u5df2\u9a8c\u8bc1\u5408\u7ea6",
                    contractAddress: "\u5408\u7ea6\u5730\u5740",
                    copy: "\u590d\u5236",
                    holders: "\u603b\u6301\u6709\u4eba",
                    marketcap: "\u603b\u5e02\u503c",
                    price: "\u4ef7\u683c",
                    totalSupply: "\u603b\u6d41\u901a",
                    timeLeft: "\u5317\u4eac\u65f6\u95f411\u67082\u53f7\u665a\u4e0a10\u70b9",
                    highestBuy: "\u53f2\u4e0a\u6700\u9ad866%\u4ea4\u6613\u5206\u7ea2",
                    highestRef: "\u53f2\u4e0a\u6700\u9ad810%\u9080\u8bf7\u8fd4\u4f63",
                    dailyInt: "2% \u53ef\u6301\u7eed\u6bcf\u65e5\u5206\u7ea2",
                    releaseIn: "\u4e0a\u7ebf\u5012\u8ba1\u65f6 ",
                    code1: "\u67e5\u770b\u5f00\u6e90\u4ee3\u7801",
                    code2: "\u67e5\u770b\u8ba4\u8bc1\u5408\u7ea6",
                    balance: "\u4f59\u989d: ",
                    days: "\u5929",
                    hours: "\u65f6",
                    minutes: "\u5206",
                    seconds: "\u79d2",
                    secondOne: "Comet \u5f57\u661f\u5e01\u4ea4\u6613\u6240\u6d88\u9664\u4e86\u52a0\u5bc6\u5e01\u5206\u7ea2\u7684\u56f0\u96be\u90e8\u5206",
                    secondTwo: "Comet \u5f57\u661f\u5e01\u4ea4\u6613\u6240\u6839\u636e\u603b\u4ea4\u6613\u91cf\u5411VipMiner\u4ee3\u5e01\u6301\u6709\u4eba\u652f\u4ed820\uff05\u7684\u5206\u7ea2\u3002\u6839\u636e\u6301\u6709\u4eba\u76f8\u5bf9\u4e8e VipMiner \u603b\u6d41\u901a\u91cf\uff0c\u6309\u6bd4\u4f8b\u5373\u65f6\u83b7\u5f97 BNB \u5206\u7ea2\u3002",
                    thirdOneOne: "\u6301\u6709 BNB",
                    thirdOneTwo: "\u53d1\u9001\u81f3\u8bf8\u5982Metamask\u6216Trust\u4e00\u7c7b\u7684WEB 3.0\u94b1\u5305",
                    thirdTwoOne: "\u8d2d\u4e70 VipMiner \u4ee3\u5e01",
                    thirdTwoTwo: "\u60a8\u5c06\u6536\u5230 BNB \u7b49\u503c VipMiner \u5e76\u5411\u6240\u6709\u4ee3\u5e01\u6301\u6709\u8005\u652f\u4ed810\uff05\u7a0e\u7387\u7528\u4e8e\u5206\u7ea2\u3002",
                    thirdThreeOne: "\u83b7\u53d6\u5206\u7ea2",
                    thirdThreeTwo: "\u4efb\u4f55\u65b0\u7684\u4ea4\u6613\uff08\u4e70\u5356\uff09\u90fd\u4f1a\u589e\u52a0\u4f60\u7684\u5206\u7ea2",
                    thirdFourOne: "\u590d\u6295\u5206\u7ea2\uff08\u80a1\u606f\uff09",
                    thirdFourTwo: "\u5c06 BNB \u5206\u7ea2\u518d\u6295\u8d44\u4ee5\u8d2d\u4e70\u66f4\u591a VipMiner \u4ee3\u5e01\u5e76\u589e\u52a0\u603b\u4f9b\u5e94\u91cf\u767e\u5206\u6bd4",
                    thirdFiveOne: "\u63d0\u73b0\u5206\u7ea2",
                    thirdFiveTwo: "\u901a\u8fc7\u667a\u80fd\u5408\u7ea6\uff0c\u76f4\u63a5\u63d0\u53d6BNB\u5230\u60a8\u7684\u94b1\u5305",
                    thirdSixOne: "\u6301\u7eed\u8d5a\u53d6 BNB",
                    thirdSixTwo: "\u6240\u6709\u5206\u7ea2\u4ee5 BNB \u5f62\u5f0f\u652f\u4ed8\uff0c\u7b80\u5355\u900f\u660e",
                    fourthOne: "VipMiner\u4ee3\u5e01\uff1aBEP-20 \u6807\u51c6 BNB \u5c06\u4e3a\u60a8\u521b\u9020\u7ea2\u5229",
                    fourthTwo: "\u901a\u8fc7\u5c06\u8ba1\u7b97\u673a\u79d1\u5b66\u4e0e\u6570\u5b66\u76f8\u7ed3\u5408\uff0cVipMiner\u4ea4\u6613\u6240\u667a\u80fd\u5408\u7ea6\u6709\u6548\u5730\u5728\u5e01\u5b89\u667a\u80fd\u94fe\u4e0a\u5206\u914d\u4e86\u5206\u7ea2\u3002"
                },
                notification: {
                    transactionSuccess: "\u4ea4\u6613\u5df2\u53d1\u9001\uff0c\u8bf7\u7b49\u5f85\u4ea4\u6613\u4e0a\u94fe\u786e\u8ba4.",
                    transactionCompelted: "\u4ea4\u6613\u5df2\u786e\u8ba4!",
                    transactionFailed: "\u4ea4\u6613\u5931\u8d25\uff0c\u8bf7\u68c0\u67e5\u8282\u70b9\u6216\u8005\u63d0\u9ad8\u77ff\u5de5\u8d39\u4e4b\u540e\u518d\u6b21\u53d1\u8d77\u4ea4\u6613",
                    loginPrompt: "\u8bf7\u767b\u5f55\u60a8\u7684BSC\u94b1\u5305",
                    investSuccess: " \u521a\u8d28\u62bc ",
                    insufficientUnstakedAmount: "\u89e3\u51bb\u4f59\u989d\u4e0d\u8db3",
                    insufficientEthBalance: "Eth \u4f59\u989d\u4e0d\u8db3",
                    invalidBuyAmount: "\u8d2d\u4e70\u6570\u91cf\u4e0d\u80fd\u4e3a0",
                    invalidSellAmount: "\u5356\u51fa\u6570\u91cf\u4e0d\u80fd\u5c11\u4e8e1VipMiner",
                    insufficientDividendsBalance: "\u5206\u7ea2\u6536\u76ca\u4e0d\u8db3",
                    insufficientProfit: "\u53ef\u63d0\u73b0\u6536\u76ca\u4e0d\u8db3",
                    comingSoon: "\u656c\u8bf7\u671f\u5f85!",
                    buyEvent: "\u4e70\u5165",
                    invested: "\u4e70\u5165\u4e86",
                    justNow: "\u521a\u521a!",
                    noWallet: "\u8bf7\u767b\u5f55\u60a8\u7684\u94b1\u5305!",
                    minDeposit: "\u6700\u5c0f\u7684\u6295\u8d44\u989d\u662f 0.01 BNB",
                    needGasFee: "\u60a8\u7684\u94b1\u5305\u9700\u8981\u9884\u7559\u5c11\u91cf\uff080.01\u4e2a\uff09BNB \u624d\u80fd\u8fdb\u884c\u4ea4\u6613",
                    insufficientBalance: "\u4f59\u989d\u4e0d\u8db3",
                    successWithdraw: "\u63d0\u53d6\u6210\u529f",
                    successBuy: "\u8d28\u62bc\u6210\u529f",
                    depositEvent: "\u91d1\u5e93\u8d28\u62bc",
                    staked: "\u8d28\u62bc\u4e86",
                    plan0: "\u4e3a\u671f 188 \u5929",
                    plan1: "\u4e3a\u671f 92 \u5929",
                    plan2: "\u4e3a\u671f 51 \u5929",
                    plan3: "\u4e3a\u671f 25 \u5929"
                },
                investSection: {
                    buyDiamond: "\u4e70\u5165 VipMiner",
                    percentDivBuy: "\u74dc\u520610%\u5206\u7ea2",
                    availableBuy: "\u53ef\u7528\u4f59\u989d:",
                    buyPrice: "\u4e70\u5165\u4ef7\u683c",
                    buyAmount: "\u4e70\u5165\u6570\u91cf",
                    cXXAmount: "\u9884\u8ba1\u53ef\u5f97 VipMiner \u6570\u91cf",
                    buyToken: "\u4e70\u5165",
                    yourTotal: "\u603b\u6536\u76ca",
                    reinvest: "\u6536\u76ca\u590d\u6295",
                    withdraw: "\u63d0\u73b0",
                    sellDiamond: "\u5356\u51fa VipMiner",
                    percentDivsell: "\u74dc\u520610%\u5206\u7ea2",
                    availableSell: "\u53ef\u5356\u6570\u91cf:",
                    sellPrice: "\u5356\u51fa\u4ef7\u683c",
                    sellAmount: "\u5356\u51fa\u6570\u91cf",
                    eTHAmount: "\u9884\u8ba1\u53ef\u5f97 BNB \u6570\u91cf",
                    sellToken: "\u5356\u51fa",
                    balance: "\u8d26\u6237\u4f59\u989d: ",
                    reinvestValue: "VipMiner \u6570\u91cf",
                    youWillGet: "\u60a8\u9884\u8ba1\u53ef\u5f97",
                    max: "\u6700\u5927\u503c",
                    reinvestPrompt: "\u590d\u6295\u60a8\u7684 BNB \u5206\u7ea2\u6536\u76ca\u53ef\u83b7\u5f97\u663e\u793a\u7684 VipMiner \u4ee3\u5e01\u6570\u91cf"
                },
                exchangeTop: {
                    yourCxxToken: "VipMiner\u4f59\u989d",
                    yourDividendEarn: "\u5206\u7ea2\u6536\u76ca",
                    yourReferralEarn: "\u9080\u8bf7\u8fd4\u4f63",
                    circulatingSupply: "\u6d41\u901a\u91cf",
                    contractCap: "\u5408\u7ea6\u4f59\u989d",
                    volume: "\u603b\u4ea4\u6613\u91cf",
                    totalDividends: "\u5e73\u53f0\u603b\u5206\u7ea2",
                    value: "\u4ef7\u503c"
                },
                referral: {
                    title: "\u9080\u8bf7\u8fd4\u4f63",
                    status: "\u9080\u8bf7\u72b6\u6001",
                    copySuccess: "\u590d\u5236\u5230\u7c98\u8d34\u677f",
                    copy: "\u590d\u5236",
                    tier1: "\u4e00\u4ee3\u9080\u8bf7",
                    tier2: "\u4e8c\u4ee3\u9080\u8bf7",
                    tier3: "\u4e09\u4ee3\u9080\u8bf7",
                    reward: "\u9080\u8bf7\u5956\u52b1",
                    referrals: "\u9080\u8bf7\u4eba\u6570:",
                    threeTierProgram: "\u603b\u9080\u8bf7\u6536\u76ca\uff1a",
                    totalRewards: "\u7d2f\u8ba1\u9080\u8bf7\u6536\u76ca:",
                    totalInvested: "\u603b\u6295\u8d44:",
                    inviteLink: "\u9080\u8bf7\u94fe\u63a5",
                    note: "\u4f60\u9700\u8981\u6301\u6709100000\u4e2a VipMiner \u6765\u6fc0\u6d3b\u9080\u8bf7\u94fe\u63a5"
                },
                vault: {
                    nodeHomepage: {
                        slogen1: "\u5f57\u661f\u91d1\u5e93\u662f\u5f57\u661f\u751f\u6001\u9996\u6b3e\u7a33\u5b9a\u6536\u76ca\u805a\u5408\u5668",
                        launchSoon: "\u5373\u5c06\u91cd\u78c5\u4e0a\u7ebf",
                        businessPlan: "\u767d\u76ae\u4e66",
                        launch: "\u8ddd\u79bb\u4e0a\u7ebf",
                        telegram: "Telegram",
                        contract: "\u5f00\u6e90\u5408\u7ea6",
                        totalInvested: "\u603b\u8d28\u62bc\u989d",
                        audit: "\u5f00\u6e90\u5408\u7ea6",
                        yourWallet: "\u60a8\u7684\u94b1\u5305: ",
                        yourWalletBalance: "\u60a8\u7684\u94b1\u5305\u4f59\u989d: ",
                        nodeDividends: "\u8282\u70b9\u5206\u7ea2\u6c60",
                        insurancePool: "\u4fdd\u9669\u57fa\u91d1"
                    },
                    planCard: {
                        earthNode: "\u5f57\u661f\u8ba1\u5212",
                        marsNode: "\u5730\u7403\u8ba1\u5212",
                        jupiterNode: "\u706b\u661f\u8ba1\u5212",
                        venusNode: "\u592a\u9633\u8ba1\u5212",
                        divEverySec: "\u6bcf\u79d2\u5206\u7ea2",
                        forever: "\u6c38\u4e45 ",
                        days: "\u65e5",
                        period: "\u6316\u77ff\u5468\u671f ",
                        totalReturn: "\u56de\u62a5\u7387",
                        minInvest: "\u6700\u5c0f\u6295\u8d44\u989d\u662f ",
                        placeholder: "BNB\u6570\u989d",
                        invest: "\u8d28\u62bc"
                    },
                    withdrawSection: {
                        dividends: "\u6211\u7684\u6536\u76ca",
                        refRewards: "\u63a8\u8350\u5956\u52b1",
                        withdrawable: "\u53ef\u63d0\u53d6\u5206\u7ea2\uff08\u5206\u7ea2+\u9080\u8bf7\uff09",
                        withdraw: "\u63d0\u53d6",
                        transacFeeNote: "\u60a8\u5e94\u8be5\u6709\u5927\u4e8e 0.01 BNB \u7684\u4ea4\u6613\u8d39",
                        myTotalInvest: "\u6211\u7684\u8d28\u62bc\u603b\u989d ",
                        myTotalDiv: "\u7d2f\u8ba1\u5206\u7ea2\u63d0\u73b0 ",
                        referral: "\u63a8\u8350\u5956\u52b1",
                        refLink: "\u4e13\u5c5e\u9080\u8bf7\u94fe\u63a5",
                        copyButton: "\u590d\u5236",
                        copySuccess: "\u5df2\u590d\u5236\u5230\u526a\u8d34\u677f",
                        copy: "\u590d\u5236",
                        bonusNote: "\u4e0d\u63d0\u73b0\u53ef\u83b7\u5f97\u6bcf\u65e50.1%\u6536\u76ca\u7b97\u529b\u52a0\u6210\uff0c\u52a0\u6210\u7b97\u529b\u53ef\u7d2f\u79ef\u3002",
                        downlineDeposits: "\u65d7\u4e0b\u603b\u4e1a\u7ee9: ",
                        tier1: "\u7b2c\u4e00\u4ee3 (5% \u63a8\u8350\u5956\u52b1) ",
                        tier2: "\u7b2c\u4e8c\u4ee3 (3% \u63a8\u8350\u5956\u52b1) ",
                        tier3: "\u7b2c\u4e09\u4ee3 (2% \u63a8\u8350\u5956\u52b1) ",
                        tier4to10: "4-10\u4ee3 (\u6bcf\u4ee3 1%) ",
                        invitee: "\u88ab\u9080\u8bf7\u4eba (\u6295\u8d44\u989d\u7684 0.5% )",
                        referrals: "\u4eba",
                        totalRefRewards: "\u603b\u63a8\u8350\u5956\u52b1 : ",
                        earned: "\u5206\u7ea2\u8d5a\u53d6 ",
                        cancel: "\u53d6\u6d88",
                        curRate: "\u5f53\u524d\u63d0\u53d6\u7387",
                        afterTaxReward: "\u60a8\u5c06\u6536\u5230",
                        harvest: "\u63d0\u53d6",
                        holdBonus: "\u4e0d\u63d0\u73b0\u53ef\u83b7\u5f97\u6bcf\u65e50.1%\u6536\u76ca\u7b97\u529b\u52a0\u6210\uff0c\u52a0\u6210\u7b97\u529b\u53ef\u7d2f\u79ef"
                    },
                    investments: {
                        myInvestments: "\u6211\u7684\u6295\u8d44",
                        plan0: "\u6bcf\u5929 2.2% ",
                        plan1: "\u6bcf\u5929 3.3% ",
                        plan2: "\u6bcf\u5929 4.1% ",
                        plan3: "\u6bcf\u5929 5.6% ",
                        payout: "\u603b\u63d0\u73b0",
                        invested: "\u8d28\u62bc\u989d",
                        withdrawable: "\u53ef\u63d0\u53d6",
                        countdown: "\u6536\u76ca\u7ed3\u675f\u5012\u8ba1\u65f6"
                    },
                    faq: {
                        noteTitle1: "\u5b89\u5168\u53ef\u9760\u7684\u9879\u76ee",
                        note1: "Heco Node\u5728\u533a\u5757\u94fe\u4e0a\u81ea\u52a8\u8fd0\u884c\uff0c\u5176\u667a\u80fd\u5408\u7ea6\u88ab\u4e0a\u4f20\u5230HECO\u533a\u5757\u94fe\u3002\u6ca1\u6709\u4eba\u80fd\u591f\u7f16\u8f91\u6216\u5220\u9664\u667a\u80fd\u5408\u7ea6\uff0c\u4e5f\u4e0d\u80fd\u5f71\u54cd\u5176\u81ea\u52a8\u64cd\u4f5c\u3002\u5206\u7ea2\u4e5f\u901a\u8fc7\u667a\u80fd\u5408\u7ea6\u81ea\u52a8\u652f\u4ed8\u3002",
                        noteTitle2: "\u6316\u77ff\u6536\u76ca\u5206\u914d",
                        note2: "Heco Node\u667a\u80fd\u5408\u7ea6\u6bcf\u5929\u6839\u636e\u60a8\u7684\u6295\u8d44\u989d\u4ea7\u751f3.5\uff05-8%\u7684\u6316\u77ff\u6536\u76ca\uff0c\u5e76\u5c06\u60a8\u7684\u6536\u76ca\u81ea\u52a8\u5206\u914d\u5230\u60a8\u7684\u4f59\u989d\u4e2d\u3002\u4f8b\u5982\uff0c\u5982\u679c\u60a8\u6295\u8d448\uff05\u7684\u5171\u8bc6\u8282\u70b9\u77ff\u6c60\u8ba1\u5212\uff0c\u90a3\u4e48\u60a8\u5c06\u572812.5\u5929\u5185\u83b7\u5f97\u8d85\u8fc7100\uff05\u7684\u672c\u91d1\u5e76\u6301\u7eed\u6536\u76ca\u3002\u77ff\u6c60\u5206\u7ea2\u6bcf\u79d2\u4ea7\u751f\u4e00\u6b21\uff0c\u60a8\u53ef\u4ee5\u6bcf\u79d2\u63d0\u53d6\u6216\u91cd\u65b0\u6295\u8d44\u60a8\u7684\u5206\u7ea2\u3002\u5f53\u60a8\u8fdb\u884c\u518d\u6295\u8d44\u65f6\uff0c\u603b\u6295\u8d44\u989d\u5c06\u589e\u52a0\uff0c\u60a8\u5c06\u83b7\u5f97\u66f4\u591a\u7684\u5206\u7ea2\u3002\u4e0d\u63d0\u73b0\u53ef\u83b7\u5f97\u6bcf\u65e50.5%\u6536\u76ca\u7b97\u529b\u52a0\u6210\uff0c\u52a0\u6210\u7b97\u529b\u53ef\u7d2f\u79ef\u3002",
                        noteTitle3: "\u8282\u70b9\u8054\u76df\u63a8\u8350\u5956\u52b1",
                        note3: "Heco Node\u667a\u80fd\u5408\u7ea6\u8bbe\u7f6e\u4e8610\u4e2a\u63a8\u8350\u5956\u52b1\u7b49\u7ea7\u603b\u8ba116%\u7684\u4f63\u91d1\u6fc0\u52b1\uff0c\u5206\u522b\u4e3a4\uff05\uff0c3\uff05\u548c 2\uff05\uff0c1%\uff0c1%\uff0c1%\uff0c1%\uff0c1%\uff0c1%\uff0c1%\u3002\u63a8\u8350\u5956\u52b1\u5c06\u81ea\u52a8\u5206\u914d\u5230\u60a8\u7684\u4f59\u989d\u4e2d\uff0c\u60a8\u53ef\u4ee5\u968f\u65f6\u63d0\u53d6\u3002",
                        q1: "\u5982\u4f55\u5728\u7535\u8111\u4e0a\u6295\u8d44?",
                        a11: "\u60a8\u53ef\u4ee5\u5b89\u88c5",
                        a1_tronlink: "MetaMask \u5c0f\u72d0\u72f8\u94b1\u5305",
                        a12: "",
                        a1_tronpay: "",
                        a13: "\u5728Chrome\u6d4f\u89c8\u5668\u4e0a\u3002\u5b89\u88c5\u540e\uff0c\u60a8\u53ef\u4ee5\u521b\u5efa\u65b0\u7684BNB\u94b1\u5305\u6216\u5bfc\u5165\u73b0\u6709\u7684BNB\u94b1\u5305\uff0c\u7136\u540e\u5c06BNB\u4ece\u4ea4\u6613\u6240\u8f6c\u79fb\u5230\u8be5\u94b1\u5305\u3002\u6700\u540e\uff0c\u767b\u5f55Metamask\u5c0f\u72d0\u72f8\u94b1\u5305\u4ee5\u6d4f\u89c8\u8be5\u7f51\u7ad9\u5e76\u8fdb\u884c\u6295\u8d44\u3002",
                        q2: "\u5982\u4f55\u5728\u624b\u673a\u4e0a\u6295\u8d44\uff1f",
                        a21: "\u60a8\u53ef\u4ee5\u4e0b\u8f7d",
                        a2_tronLinkPro: "Huobi\u94b1\u5305",
                        a22: " , ",
                        a2_dappBirds: "",
                        a2_tokenPocket: "TokenPocket",
                        a23: " \u6216 ",
                        a2_tronWallet: "BitKeep",
                        a24: " \u5e94\u7528\u7a0b\u5e8f\u3002\u5b89\u88c5\u540e\uff0c\u60a8\u53ef\u4ee5\u521b\u5efa\u65b0\u7684BNB\u94b1\u5305\u6216\u5bfc\u5165\u73b0\u6709\u7684BNB\u94b1\u5305\uff0c\u7136\u540e\u5c06BNB\u4ece\u4ea4\u6613\u6240\u8f6c\u79fb\u5230\u8be5\u94b1\u5305\u3002\u6700\u540e\uff0c\u5728\u7535\u5b50\u94b1\u5305\u5e94\u7528\u7a0b\u5e8f\u4e2d\u627e\u5230Heco Node\u6216\u4f7f\u7528\u8be5\u5e94\u7528\u7a0b\u5e8f\u4e2d\u7684\u6d4f\u89c8\u5668\u767b\u5f55\u6d4f\u89c8\u6211\u4eec\u7684\u7f51\u7ad9\uff0c\u7136\u540e\u8fdb\u884c\u6295\u8d44\u6216\u63d0\u6b3e\u3002",
                        q3: "\u8d44\u91d1\u5c06\u5982\u4f55\u5206\u914d\uff1f",
                        a3: "\u6280\u672f\u652f\u6301\uff1a1\uff05 \u5e02\u573a\u8425\u9500\uff1a2\uff05 \u63a8\u8350\u5956\u52b1\uff1a6\uff05-4\uff05-2\uff05 \u88ab\u9080\u8bf7\u8005\uff1a0.5\uff05\uff0cJustSwap \u6d41\u52a8\u6027\uff1a15\uff05",
                        q4: "\u4ec0\u4e48\u662f\u8282\u70b9\u8054\u76df\u63a8\u8350\u5956\u52b1\uff1f",
                        a4: "Heco Node\u667a\u80fd\u5408\u7ea6\u8bbe\u7f6e\u4e8610\u4e2a\u63a8\u8350\u5956\u52b1\u7b49\u7ea7\u603b\u8ba116%\u7684\u4f63\u91d1\u6fc0\u52b1\uff0c\u5206\u522b\u4e3a4\uff05\uff0c3\uff05\u548c 2\uff05\uff0c1%\uff0c1%\uff0c1%\uff0c1%\uff0c1%\uff0c1%\uff0c1%\u3002\u63a8\u8350\u5956\u52b1\u5c06\u81ea\u52a8\u5206\u914d\u5230\u60a8\u7684\u4f59\u989d\u4e2d\uff0c\u60a8\u53ef\u4ee5\u968f\u65f6\u63d0\u53d6\u3002",
                        q5: "\u4ec0\u4e48\u662f\u6301\u6709\u7b97\u529b\u52a0\u6210\uff1f",
                        a5: "Heco Node\u667a\u80fd\u5408\u7ea6\u72ec\u521b\u4e86\u6301\u6709\u7b97\u529b\u52a0\u6210\u673a\u5236\uff08hold bonus\uff09\uff0c\u77ff\u5de5\u4eec\u4e0d\u63d0\u73b0\u6536\u76ca\u7684\u60c5\u51b5\u4e0b\uff0c\u53ef\u83b7\u5f97\u6536\u76ca\u7b97\u529b\u52a0\u62100.5%/\u5929\u3002\u7b97\u529b\u52a0\u6210\u53ef\u6bcf\u5929\u7d2f\u79ef\uff0c\u77ff\u5de5\u63d0\u73b0\u7684\u65f6\u5019\u4f1a\u91cd\u7f6e\u7b97\u529b\u52a0\u6210\u90e8\u5206\uff0c\u57fa\u7840\u6536\u76ca\u7387\u4e0d\u53d8\u3002"
                    }
                }
            }
        },
        439: function(e, t, a) {},
        440: function(e, t, a) {},
        441: function(e, t, a) {},
        442: function(e, t) {
            e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHoAAAB6CAYAAABwWUfkAAAK5UlEQVR42u2de5AcRRnAR9DcTfflbnt2eu5uusEYUaHKqBhFAlpqKpBSqZKCAkksEQofsSjRMlAYIwViBApMQqqgFGJ8oRihUipqrns3EmMCWnpERYhgSUyMSRCEmb08zhjCWt/s3nGP3b2Z3ZnZmdnuqv5zZ2f7t9/XX3+v1rSMDGSag315e1GO8muIxe4hlD1MKBs2KNtFLLaHWOx5w2JHDIuXvUnZIYPy/QZlTxmU/4FQPmRQtpZYbFnO5O/FltWvqdH+kTPZ+w2L3Uwo30Yod8cBhjjhz0Eoe4hQ/sW+PFuoaTZSKx/x6DMH304o+5JhsWIUUH3Dp2yHYfEbe/P8XYpKWFKbG3xtjrIve+q1jXDrQ+euQfm3evP8LEUr6Ojvx4bJP1GVnHJaJqHsT/DeSr3PMHp7uVHdc19ME+BaUk4oWwW/R1GdMAyDcYOyOydZxJmY7HDOYquV9Q4qmtrrsgW3npTbt8Lv7cyjEWX7OgHyK+d2ftCg9lWapp2UecCEkD6Dsu90FODpZ/M/w1Exu5Ap/yCx2HOdDHmyhLOvZg+yxe9QcGvC3pUJ6TYM+xTP36ygNlDl/Bj419PrsrTs86PyQWdUuh/UNK6ny6oGt6WC14x0P6HnOUsD45MJZd9T0FqyyveAjz+5iCntgRiwghXKmftfff39cxPHGNx8xOJ/UZDCdbDMztunJ8qVSSz+uIITCez9SZHsk9udCJB9Pzn7JzJNu73nZMq+q2DEcvR6uqen32pXYOIGBSFWyd6paVpX3JJ8iVr8tpyzfxgbZLAEs5ckkKJpsi/EclaG/UIteHsn5J1HHGpkv1ALnQjv2T8i84sTy75OLXKi9us7ws/QpPw0tbg1HRqCED7Pf9jW6CXUvi2s7+8zB+eHrbKVD3uqRJn20pYEh7K/hZGWFB5k075MgZ12pl3Zev4cnxfOH459OiQrmx9QcCfNo5ppzg7HH8FFGIWAsCW06hi5U4GdVomxLTTHk8mWt90wg3wvBbZmBcaWEDNxrgjtbJ0bmNOsAXa3gho1aPvKEE8AGwK/AHQPgOxEBTU9oAllxwOnIHVKTVSmJBrUN+XrA6UFKZjp26PHp8G43715pYKZTomuzq/4LZ95RsFMMWjKD8xYsQl1QBmCMkoo/7W/ybZnRnVXvGUfamyEWWxNJuK1lK8P2mlgtmm/yZ+nKgWgKXtoJtDPpj/YwC6Itpwo+aBh1o1X91n2eRkIyH8zpGjdH9MO2rDsc+r5tdemHXRYlQ2NjaSUgKbs0nrW9hMpDx2eCNEaPjPFx6uKnZK3L8yskyS02u6+/telXaIJ6X9zreSCpQr0BND9/XNTDZry/fUC4BsU6AxJtMmWZ9obpiTaS0J4pt73dWUkj+t4+kCHbowdrdvlqLGFqUCnKB59Anq5NcryXKJAZwC0yT41g9uT39QGD9ajfgMOBmUjyhib0f++xo+7b2OcGZQ5i701ULJ7LzeIxb6hQNc1vn7i1687HJNqXdXS4uftRQr0tHf5re9iuzjKYMG9qmnaq1oPNvC71B49/nsfgwIL/4tnsT3RF6N5fapbHr2Uv0FJtAd5GFpi+/2eQ1KzNK9heOQSbZ8b1uI06i/aCaBBkoNAdgS62S3g87VYGrMabEFYiwNd9TpVdUM/tyCQR0T3e1yJy86QfhEcr0ZjAH121KCzLtFw3VKQm3fKRa3PFegggC4V9CVaLEcrBbpF0KwYtILTkejnANkDLfDHQHX/T6nu5Kpu6JYMHRqDPLck9c+OQfZmQb9EC+J5UqDjA00oexnu4gz6TKeIzpwEGSS6iBdrsVxookAHAg0FjjmLXxT0eUcKyHYlfnYq6JGCfi6A3qv26OTs0SB4hNrvDvqs8g5ttivxX6dChnm4OGseuEB3KolOhkQTiz2CKR0IDHmr9mpH4m21IFeOV91zwBjbrEC3HzQx+e1Bja6x4Uq8sR7kitWtGVosN8sp0HVBV26n5R9o9hmORDc1guwK9N+x6NUtao+eAiA3MCcO0OAaBnug2c+7Ai1rCBnUtsCVXmSQmaAkuj0S3cpwBL5yJsgVicY/riycZZ+jQKcLdEnoS12JXvYDGoIalU9B0zgFOjWgPcgCnfAlzWCIye6PToxJ71V7dPzn6OB7sn5xEMiVieZPXLxNSqKTLdG+9+SJaluio5MXz7KvVaCTC9qVaFVQyFVDrDjNzFegkwcaPF6uxD9qCnJlrpj6zG61R/vbo8GTGAvkzVqvI9D2FiCXS0I/q9YCCgXahzFG7XVRQz4q9VNcgZ9uBbIj0eHaXhpqX61Utx/VXac3SGj7cfdCV+L/tAK5am3XTuyH1oJKohtLNKH8+mgh4xWuQC+1DhnOz/pl9X2vlD2mQE+XaOhS1EyMOIDR1eNKtDkMwGNqu7y5wfWGOZN9XoGuBDWIxV8gFruvL88WRinFI3LW6a5Eu8OCXFXb9zb8UrjRVIGunEJicYIU8BWuRKPhQsblEanPbEdEkoiQMmMs6gElMmGq6inSvNuf2srbFyqJjlJV44+7Ar8YDWRvXuv3XU4iFt+dNomu23KpI6R4PMlgBAw73y9FLPaZ1Ek05ZuSCrkk8OWOxG6UkKtq+5aAr8Z1sDrTBDpoJ4VYpLg46wxHokeiB+zlhh0b2aqZgV8SrsJLA2joh9KTHzwjSYBBfZYEXu1KdDwWyBVpvqfpF27czrh9oKGyMGex1YY1uDhxarqgL3EEOhAf4Or8VdfrmwcdUviSEPvUsBYSmaadxH3YKeC3uRI/HDtgz92J17T8A1q977hye3l2B0SaHIl/4DdZL4K9+WAgS7uxZPP7m77MOm8vyiJgiBe7Ur8dEuTbAnh86h8J9YcRy77OsNiRAJK8N6uQSwV0tSvwC+0F7KUKRZTtYpqzicWWEcu+16BcQlpNRdrZGkLZCsPkn4Ryz978wDuzBtfdrpFSAd3gSvzvtgOuWNmjLRlgakweUHNcknitI9GhZACuGmDQl0SN1gfUFDsS35ckuL7DkGrMYGANa6+BzAxH4N8kEzAkFeDHy09qsxStZqR3Kx7wGq9V2zUlGLILxzlFLKj1XMSLXYkfSDLcyVZ29yJFzXckqes0V6CvOQLtSw3gSq+wyxU9H0EGV6KrHIl2pAnu9NJXNaYfiwQarHQEQL+MIi8rxrlR0Zzq1Cigd3hGlUTDKQY7cRYU1Yq/uWtEogsgFutItD8jcMeCFZvguNexcCGLwttvBfqpI9CRTMF9pXfnbZ0HdkvXG738Z4HWOwI/2bZwYDxS/JLXiTf7Rx/NgG7xrsDXOwL9zBX4+cxCnZ7BWfI65WfOcNrSPRf215JEN1bV8L5OgVpDkn+fCY8XlIJ6IT6B73cF2tmxQGvHlL+eKV+yK5FUYCf7rV2Jz8vmOVfol7oCP9fxkAX+Pvz5s29wSbShQyHv8pqkd9SxaUhf4Ar8VKeo6ZLUryk/0Fyb5myoc4lXJC1NJ8y8LkhDGtmi5ZUfc+yOJolWZmb/FuiYI9Bd3lWBatQA/qime1f5CPT3FEP+9mix+1RF07dKR/MhQd4RaE/CwZ6AVoxQ4B5axUTHBjKG9AVwpUBsJaj+9t/fOUJfDnFvRSgK9Q7X/gj9YkfideA6jDP7EorZRgT6MLyDItGOs3lRP7sk9M9BvrOXqtusUQef8/486EFX6rdC6Q0kECqrOeGSD22YnKHu902d8Mc4PITfAiUtoHqhYC7r6/F/aNYZcP5NFBYAAAAASUVORK5CYII="
        },
        459: function(e, t) {},
        463: function(e, t) {},
        487: function(e, t) {},
        489: function(e, t) {},
        498: function(e, t) {},
        500: function(e, t) {},
        510: function(e, t) {},
        512: function(e, t) {},
        643: function(e, t) {},
        680: function(e, t) {},
        682: function(e, t) {},
        689: function(e, t) {},
        690: function(e, t) {},
        714: function(e, t) {},
        721: function(e, t) {},
        769: function(e, t) {},
        811: function(e, t, a) {},
        812: function(e, t, a) {
            "use strict";
            a.r(t);
            var n = a(0),
                r = a.n(n),
                i = a(19),
                s = a.n(i),
                o = a(828),
                l = (a(361), a(17)),
                c = a.n(l),
                u = a(39),
                d = a(4),
                p = a(5),
                m = a(6),
                y = a(9),
                f = a(3),
                g = a(818);
            a(364);

            function h(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var a, n = Object(f.a)(e);
                    if (t) {
                        var r = Object(f.a)(this).constructor;
                        a = Reflect.construct(n, arguments, r)
                    } else a = n.apply(this, arguments);
                    return Object(y.a)(this, a)
                }
            }
            n.Component, a(367);

            function b(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var a, n = Object(f.a)(e);
                    if (t) {
                        var r = Object(f.a)(this).constructor;
                        a = Reflect.construct(n, arguments, r)
                    } else a = n.apply(this, arguments);
                    return Object(y.a)(this, a)
                }
            }
            var v = function(e) {
                    Object(m.a)(n, e);
                    var t = b(n);

                    function n(e) {
                        var a;
                        return Object(d.a)(this, n), (a = t.call(this, e)).showStacking = function() {
                            a.setState({
                                visible: !0
                            })
                        }, a.handleClose = function(e) {
                            a.setState({
                                visible: !1
                            })
                        }, a.state = {
                            visible: !1
                        }, a
                    }
                    return Object(p.a)(n, [{
                        key: "render",
                        value: function() {
                            return r.a.createElement("div", {
                                className: "footer",
                                align: "middle"
                            }, r.a.createElement("a", {
                                href: "https://twitchain.online",
                                target: "_blank",
                                rel: "noopener noreferrer"
                            }, r.a.createElement("span", {
                                className: "clickableButtonFooter",
                                onClick: this.showStacking,
                                style: {
                                    paddingRight: "3px",
                                    paddingTop: "3px",
                                    display: "inline-block"
                                }
                            }, r.a.createElement("img", {
                                src: a(152),
                                alt: "telegram",
                                width: "25px"
                            }))), r.a.createElement("a", {
                                href: "https://t.me/Bnbfaucetminer",
                                target: "_blank",
                                rel: "noopener noreferrer"
                            }, r.a.createElement("span", {
                                className: "clickableButtonFooter",
                                onClick: this.showStacking,
                                style: {
                                    paddingRight: "3px",
                                    paddingTop: "3px",
                                    display: "inline-block"
                                }
                            }, r.a.createElement("img", {
                                src: a(213),
                                alt: "twitter",
                                width: "25px"
                            }))), r.a.createElement("p", null, "BNB FAUCET \xa9 2023"))
                        }
                    }]), n
                }(n.Component),
                A = a(830),
                w = a(831),
                E = a(822),
                B = a(826),
                k = a(821),
                S = a(829),
                C = a(832),
                T = a(825),
                N = (a(824), a(368)),
                M = a(369),
                I = a(370),
                Q = a(371),
                x = "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
                R = "0xe9e7cea3dedca5984780bafc599bd69add087d56",
                W = {
                    web3: !1,
                    vipMiner: !1,
                    vipMinerAddress: I.address,
                    ownerAddr: "0x8a75d2F601913dA221d20fD1727D608EA2CEB95A",
                    setWeb3: function() {
                        var e = Object(u.a)(c.a.mark(function e(t) {
                            return c.a.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        this.web3 = t, this.vipMiner = new t.eth.Contract(I.abi, I.address), this.cakeFactory = new t.eth.Contract(N.abi, "0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73"), this.busd = new t.eth.Contract(Q.abi, R), this.wbnb = new t.eth.Contract(Q.abi, x), this.multiCall = new t.eth.Contract(M, "0xE1dDc30f691CA671518090931e3bFC1184BFa4Aa");
                                    case 6:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, this)
                        }));
                        return function(t) {
                            return e.apply(this, arguments)
                        }
                    }()
                },
                F = "Tue July 05 2022 14:00:00 UTC",
                O = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : F;
                    return !(!W.web3 || !W.web3.currentProvider.selectedAddress || "0x583c71D6fc6f5e8e26ef612b55F3eC42243f3A97".toLowerCase() !== W.web3.currentProvider.selectedAddress.toLowerCase()) || (new Date).getTime() / 1e3 >= new Date(e).getTime() / 1e3
                },
                U = a(214),
                K = function(e) {
                    var t = e.toUTCString();
                    return t.substring(0, 3) + t.substring(7, 12) + t.substring(5, 7) + t.substring(11, t.length - 4) + " UTC"
                };
            a(373);

            function D(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var a, n = Object(f.a)(e);
                    if (t) {
                        var r = Object(f.a)(this).constructor;
                        a = Reflect.construct(n, arguments, r)
                    } else a = n.apply(this, arguments);
                    return Object(y.a)(this, a)
                }
            }
            var j = a(214),
                V = function(e) {
                    Object(m.a)(n, e);
                    var t = D(n);

                    function n(e) {
                        var a;
                        return Object(d.a)(this, n), (a = t.call(this, e)).tipFormatter = function(e) {
                            return e + "%"
                        }, a.isMobile = function() {
                            return !!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
                        }, a.onBuyValueChange = function(e) {
                            isNaN(e) || (a.setState({
                                input: e
                            }), "" !== e && Number(e) > 0 ? a.calcMiner(W.web3.utils.toWei(e)) : a.setState({
                                minersBuy: 0
                            }))
                        }, a.calcMiner = function(e) {
                            W.vipMiner && (console.log(e), W.vipMiner.methods.calcMinerBuy(e).call({
                                from: a.props.address
                            }).then(function(e) {
                                a.setState({
                                    minersBuy: e
                                })
                            }).catch(function(e) {
                                console.log(e)
                            }))
                        }, a.maxBuy = function() {
                            a.onBuyValueChange((a.props.state.nativeBalance - .005).toString())
                        }, a.buy = function() {
                            if (O())
                                if (a.props.address && "0x00000000000000000000000000000000deadbeef" !== a.props.address)
                                    if (Number(a.props.state.nativeBalance) < Number(a.state.input)) k.a.warning("Insufficient BNB");
                                    else if (0 !== a.state.minersBuy) try {
                                var e = W.web3.utils.toWei(a.state.input),
                                    t = new URLSearchParams(window.location.search.split("?")[1]).get("ref"),
                                    n = W.ownerAddr;
                                W.web3.utils.isAddress(t) && (n = t), console.log(n), W.vipMiner.methods.buyEggs(n).send({
                                    from: a.props.address,
                                    value: e
                                }).on("transactionHash", function(e) {
                                    console.log(e), k.a.info("Transaction sent", 3)
                                }).once("receipt", function(e) {
                                    console.log(e), k.a.info("Transaction confirmed", 3)
                                }).catch(function(e) {
                                    return console.log(e)
                                })
                            } catch (r) {
                                console.log(r)
                            } else k.a.warning("Invest more BNB in order to purchase 1 miner");
                            else a.toggleDisplayWalletModal();
                            else k.a.info("Coming Soon")
                        }, a.compound = Object(u.a)(c.a.mark(function e() {
                            var t, n, r, i;
                            return c.a.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (O()) {
                                            e.next = 3;
                                            break
                                        }
                                        return k.a.info("Coming Soon!"), e.abrupt("return");
                                    case 3:
                                        if (!(1 * a.props.state.nativeBalance < .001)) {
                                            e.next = 6;
                                            break
                                        }
                                        return k.a.warning("Insufficient Gas"), e.abrupt("return");
                                    case 6:
                                        if (t = 0, !(a.props.state.myEarns && 1 * a.props.state.myEarns > 0)) {
                                            e.next = 11;
                                            break
                                        }
                                        return e.next = 10, W.vipMiner.methods.calcMinerBuy(W.web3.utils.toWei(a.props.state.myEarns)).call({
                                            from: a.props.address
                                        });
                                    case 10:
                                        t = e.sent;
                                    case 11:
                                        if (0 !== Number(t)) {
                                            e.next = 14;
                                            break
                                        }
                                        return k.a.warning("Current earnings is not enough for boosting"), e.abrupt("return");
                                    case 14:
                                        try {
                                            n = new URLSearchParams(window.location.search.split("?")[1]), r = n.get("ref"), i = W.ownerAddr, W.web3.utils.isAddress(r) && (i = r), console.log(i), W.vipMiner.methods.hatchEggs(i, 0).send({
                                                from: a.props.address
                                            }).on("transactionHash", function(e) {
                                                console.log(e), k.a.info("Transaction sent", 3)
                                            }).once("receipt", function(e) {
                                                console.log(e), k.a.info("Transaction confirmed", 3)
                                            }).catch(function(e) {
                                                return console.log(e)
                                            })
                                        } catch (s) {
                                            console.log(s)
                                        }
                                    case 15:
                                    case "end":
                                        return e.stop()
                                }
                            }, e)
                        })), a.withdraw = function() {
                            if (O())
                                if (1 * a.props.state.nativeBalance < .001) k.a.warning("Insufficient Gas");
                                else try {
                                    W.vipMiner.methods.sellEggs().send({
                                        from: a.props.address
                                    }).on("transactionHash", function(e) {
                                        console.log(e), k.a.info("Transaction sent", 3)
                                    }).once("receipt", function(e) {
                                        console.log(e), k.a.info("Transaction confirmed", 3)
                                    }).catch(function(e) {
                                        return console.log(e)
                                    })
                                } catch (e) {
                                    console.log(e)
                                } else k.a.info("Coming Soon!")
                        }, a.state = {
                            input: ""
                        }, a
                    }
                    return Object(p.a)(n, [{
                        key: "render",
                        value: function() {
                            var e = this;
                            return r.a.createElement("div", {
                                className: "investment"
                            }, r.a.createElement(S.a, {
                                type: "flex",
                                justify: "space-between",
                                align: "middle",
                                gutter: 30
                            }, r.a.createElement(C.a, {
                                xs: 24,
                                sm: 24,
                                md: 24
                            }, r.a.createElement("div", {
                                className: "cardDisplay purchaseBox"
                            }, r.a.createElement("div", {
                                className: "bgImg"
                            }, r.a.createElement("img", {
                                src: a(421),
                                alt: "hire"
                            })), r.a.createElement("div", {
                                className: "verticalTextContainer",
                                align: "middle"
                            }, r.a.createElement("h2", null, this.props.languageFile.investSection.buyDiamond), r.a.createElement(T.a, {
                                addonBefore: r.a.createElement("img", {
                                    src: a(166),
                                    style: {
                                        verticalAlign: "middle"
                                    },
                                    alt: "ill1",
                                    width: "15px"
                                }),
                                style: {
                                    textAlign: "center",
                                    width: "80%",
                                    height: "30px"
                                },
                                placeholder: "Amount Of BNB",
                                type: "number",
                                value: this.state.input,
                                suffix: r.a.createElement("span", null, r.a.createElement("span", {
                                    className: "max",
                                    onClick: function() {
                                        e.maxBuy()
                                    }
                                }, this.props.languageFile.investSection.max)),
                                onChange: function(t) {
                                    return e.onBuyValueChange(t.target.value)
                                }
                            }), r.a.createElement("p", {
                                className: "clickableButton",
                                onClick: function() {
                                    e.buy()
                                }
                            }, "Hire Miners"), r.a.createElement("p", {
                                className: "balance"
                            }, this.props.languageFile.investSection.balance, " ", j(this.props.state.nativeBalance).format("0,0.000000"), " BNB")))), r.a.createElement(C.a, {
                                xs: 24,
                                sm: 24,
                                md: 12
                            }, r.a.createElement("div", {
                                className: "cardDisplay purchaseBox"
                            }, r.a.createElement("div", {
                                className: "",
                                align: "middle"
                            }, r.a.createElement("div", {
                                className: "withdrawTop"
                            }, r.a.createElement("img", {
                                src: a(431),
                                style: {
                                    verticalAlign: "middle",
                                    width: "auto"
                                },
                                alt: "ill1",
                                height: "100px"
                            }), r.a.createElement("p", {
                                style: {
                                    verticalAlign: "middle",
                                    fontSize: "20px"
                                },
                                className: "middleWords"
                            }, "Mining Power"), r.a.createElement("h1", null, j(this.props.state.myMiners).format("0,0"), " Miners"), r.a.createElement("p", {
                                className: "clickableButton",
                                onClick: function() {
                                    e.compound()
                                },
                                style: {
                                    marginTop: "10px",
                                    width: "90%"
                                }
                            }, "Boost Mining Power"))))), r.a.createElement(C.a, {
                                xs: 24,
                                sm: 24,
                                md: 12
                            }, r.a.createElement("div", {
                                className: "cardDisplay purchaseBox"
                            }, r.a.createElement("div", {
                                className: "",
                                align: "middle"
                            }, r.a.createElement("div", {
                                className: "withdrawTop"
                            }, r.a.createElement("img", {
                                src: a(166),
                                style: {
                                    padding: "10px",
                                    width: "auto"
                                },
                                alt: "ill1",
                                height: "100px"
                            }), r.a.createElement("p", {
                                style: {
                                    verticalAlign: "middle",
                                    fontSize: "20px"
                                },
                                className: "middleWords"
                            }, "BNB Mined"), r.a.createElement("h1", null, j(this.props.state.myEarns).format("0,0.[000000]"), " BNB"), r.a.createElement("p", {
                                className: "clickableButton",
                                onClick: function() {
                                    e.withdraw()
                                },
                                style: {
                                    marginTop: "10px",
                                    width: "90%"
                                }
                            }, "Withdraw Your BNB")))))))
                        }
                    }]), n
                }(n.Component);
            a(432);

            function Z(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var a, n = Object(f.a)(e);
                    if (t) {
                        var r = Object(f.a)(this).constructor;
                        a = Reflect.construct(n, arguments, r)
                    } else a = n.apply(this, arguments);
                    return Object(y.a)(this, a)
                }
            }
            var P = function(e) {
                Object(m.a)(a, e);
                var t = Z(a);

                function a(e) {
                    var n;
                    return Object(d.a)(this, a), (n = t.call(this, e)).componentDidUpdate = function(e) {
                        n.props.date !== e.date && (n.interval = setInterval(function() {
                            var e = n.calculateCountdown(n.props.date);
                            e ? n.setState(e) : n.stop()
                        }, 1e3))
                    }, n.isMobile = function() {
                        return !!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
                    }, n.state = {
                        days: 0,
                        hours: 0,
                        min: 0,
                        sec: 0
                    }, n
                }
                return Object(p.a)(a, [{
                    key: "componentDidMount",
                    value: function() {
                        var e = this;
                        this.interval = setInterval(function() {
                            var t = e.calculateCountdown(e.props.date);
                            t ? e.setState(t) : e.stop()
                        }, 1e3)
                    }
                }, {
                    key: "componentWillUnmount",
                    value: function() {
                        this.stop()
                    }
                }, {
                    key: "calculateCountdown",
                    value: function(e) {
                        var t = (Date.parse(new Date(e)) - Date.parse(new Date)) / 1e3;
                        if (t <= 0) return !1;
                        var a = {
                            years: 0,
                            days: 0,
                            hours: 0,
                            min: 0,
                            sec: 0
                        };
                        return t >= 31557600 && (a.years = Math.floor(t / 31557600), t -= 365.25 * a.years * 86400), t >= 86400 && (a.days = Math.floor(t / 86400), t -= 86400 * a.days), t >= 3600 && (a.hours = Math.floor(t / 3600), t -= 3600 * a.hours), t >= 60 && (a.min = Math.floor(t / 60), t -= 60 * a.min), a.sec = t, a
                    }
                }, {
                    key: "stop",
                    value: function() {
                        clearInterval(this.interval)
                    }
                }, {
                    key: "addLeadingZeros",
                    value: function(e) {
                        for (e = String(e); e.length < 2;) e = "0" + e;
                        return e
                    }
                }, {
                    key: "render",
                    value: function() {
                        var e = this.state;
                        return r.a.createElement("span", {
                            className: "Countdown",
                            align: "middle"
                        }, !this.props.dayOff && parseInt(e.days) > 0 ? r.a.createElement("span", {
                            className: "Countdown-col"
                        }, r.a.createElement("span", {
                            className: "Countdown-col-element"
                        }, r.a.createElement("strong", null, this.addLeadingZeros(e.days), "\xa0:\xa0"))) : null, r.a.createElement("span", {
                            className: "Countdown-col"
                        }, r.a.createElement("span", {
                            className: "Countdown-col-element"
                        }, r.a.createElement("strong", null, this.addLeadingZeros(e.hours), "\xa0:\xa0"))), r.a.createElement("span", {
                            className: "Countdown-col"
                        }, r.a.createElement("span", {
                            className: "Countdown-col-element"
                        }, r.a.createElement("strong", null, this.addLeadingZeros(e.min), "\xa0:\xa0"))), r.a.createElement("span", {
                            className: "Countdown-col"
                        }, r.a.createElement("span", {
                            className: "Countdown-col-element"
                        }, r.a.createElement("strong", null, " ", this.addLeadingZeros(e.sec)))))
                    }
                }]), a
            }(n.Component);
            P.defaultProps = {
                date: new Date
            };
            var H = P,
                J = a(344);
            a(436);

            function q(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var a, n = Object(f.a)(e);
                    if (t) {
                        var r = Object(f.a)(this).constructor;
                        a = Reflect.construct(n, arguments, r)
                    } else a = n.apply(this, arguments);
                    return Object(y.a)(this, a)
                }
            }
            var z = null,
                L = "https://bnbfaucetminer.online?ref=",
                X = null,
                Y = function(e) {
                    Object(m.a)(n, e);
                    var t = q(n);

                    function n(e) {
                        var r;
                        Object(d.a)(this, n), (r = t.call(this, e)).componentDidUpdate = function(e) {
                            r.props.address !== e.address && (r.checkContract(), r.setState({
                                referralLink: L + r.props.address
                            })), r.props.totalSupply !== e.totalSupply && r.checkContract()
                        }, r.componentWillUnmount = function() {
                            clearInterval(X)
                        }, r.componentDidMount = function() {
                            X = setInterval(function() {
                                r.checkContract()
                            }, 1e3), r.setState({
                                referralLink: L + r.props.address
                            })
                        }, r.checkContract = function() {
                            W.vipMiner && W.web3 && r.props.address && (clearInterval(X), r.fetchReferralData())
                        }, r.fetchReferralData = function() {
                            W.vipMiner.methods.referralData(r.props.address).call({
                                from: r.props.address
                            }).then(function(e) {
                                r.setState({
                                    affCount1Sum: e.affCount1Sum,
                                    affCount2Sum: e.affCount2Sum,
                                    affCount3Sum: e.affCount3Sum,
                                    tierInvest1Sum: Math.floor(1e6 * W.web3.utils.fromWei(e.tierInvest1Sum)) / 1e6,
                                    tierInvest2Sum: Math.floor(1e6 * W.web3.utils.fromWei(e.tierInvest2Sum)) / 1e6,
                                    tierInvest3Sum: Math.floor(1e6 * W.web3.utils.fromWei(e.tierInvest3Sum)) / 1e6
                                }, function() {
                                    r.setState({
                                        totalRewarded: (5 * r.state.tierInvest1Sum / 100 + 4 * r.state.tierInvest2Sum / 100 + 3 * r.state.tierInvest3Sum / 100).toFixed(4)
                                    })
                                })
                            }).catch(function(e) {
                                return console.log(e)
                            })
                        }, r.state = {
                            visible: !1,
                            width: 60,
                            referralLink: L,
                            affCount1Sum: 0,
                            affCount2Sum: 0,
                            affCount3Sum: 0,
                            tierInvest1Sum: 0,
                            tierInvest2Sum: 0,
                            tierInvest3Sum: 0,
                            totalRewarded: 0
                        };
                        var i = sessionStorage.getItem("lang") || "en";
                        return z = a(167)("./" + i + ".json"), r
                    }
                    return Object(p.a)(n, [{
                        key: "render",
                        value: function() {
                            return r.a.createElement("div", {
                                className: "InvestmentSection ReferralInvest"
                            }, r.a.createElement("div", {
                                className: "investPrompt"
                            }, r.a.createElement("h2", null, this.props.languageFile.referral.title)), r.a.createElement("div", {
                                className: "referralLinkSection",
                                align: "middle"
                            }, r.a.createElement("div", {
                                className: "referralLinkInner",
                                align: "middle"
                            }, r.a.createElement("p", {
                                style: {
                                    marginBottom: "5px",
                                    textAlign: "middle"
                                }
                            }, this.props.languageFile.referral.inviteLink), r.a.createElement(S.a, {
                                type: "flex",
                                justify: "start",
                                align: "middle"
                            }, r.a.createElement(C.a, {
                                xs: 20,
                                sm: 20,
                                md: 20
                            }, r.a.createElement("p", {
                                className: "referralLink"
                            }, this.state.referralLink, " ")), r.a.createElement(C.a, {
                                xs: 4,
                                sm: 4,
                                md: 4
                            }, r.a.createElement("div", {
                                className: "copyButton",
                                align: "left"
                            }, r.a.createElement(J.CopyToClipboard, {
                                text: this.state.referralLink,
                                onCopy: function() {
                                    k.a.success(z.referral.copySuccess)
                                }
                            }, r.a.createElement("span", null, this.props.languageFile.referral.copy)))), r.a.createElement("p", {
                                className: "smallNote"
                            }, "You can earn referral rewards up to 12% from three levels. Rewards are reflected in the BNB Miner section.")))), r.a.createElement("div", {
                                align: "middle",
                                className: "referralStatus"
                            }, r.a.createElement(S.a, {
                                type: "flex",
                                justify: "space-around",
                                align: "middle",
                                className: "referralTierSection"
                            }, r.a.createElement(C.a, {
                                xs: 6,
                                sm: 6,
                                md: 6
                            }, r.a.createElement("div", {
                                align: "middle"
                            }, r.a.createElement("div", {
                                className: "referralTierBox"
                            }, this.props.languageFile.referral.tier1))), r.a.createElement(C.a, {
                                xs: 2,
                                sm: 2,
                                md: 2
                            }, r.a.createElement("hr", {
                                style: {
                                    border: "none",
                                    borderTop: "2px dashed",
                                    color: "#52C6F9",
                                    height: "2px"
                                }
                            })), r.a.createElement(C.a, {
                                xs: 6,
                                sm: 6,
                                md: 6
                            }, r.a.createElement("div", {
                                align: "middle"
                            }, r.a.createElement("div", {
                                className: "referralTierBox"
                            }, this.props.languageFile.referral.tier2))), r.a.createElement(C.a, {
                                xs: 2,
                                sm: 2,
                                md: 2
                            }, r.a.createElement("hr", {
                                style: {
                                    border: "none",
                                    borderTop: "2px dashed",
                                    color: "#52C6F9",
                                    height: "2px"
                                }
                            })), r.a.createElement(C.a, {
                                xs: 6,
                                sm: 6,
                                md: 6
                            }, r.a.createElement("div", {
                                align: "middle"
                            }, r.a.createElement("div", {
                                className: "referralTierBox"
                            }, this.props.languageFile.referral.tier3)))), r.a.createElement(S.a, {
                                type: "flex",
                                justify: "space-around",
                                align: "middle",
                                className: "referralTierSection",
                                style: {
                                    paddingTop: "0"
                                }
                            }, r.a.createElement(C.a, {
                                xs: 6,
                                sm: 6,
                                md: 6
                            }, r.a.createElement("div", {
                                align: "middle"
                            }, r.a.createElement("p", null, "5% ", this.props.languageFile.referral.reward), r.a.createElement("h5", null, this.props.languageFile.referral.referrals, " ", this.state.affCount1Sum, " "), r.a.createElement("h5", null, this.props.languageFile.referral.totalInvested, " ", this.state.tierInvest1Sum, " BNB"))), r.a.createElement(C.a, {
                                xs: 2,
                                sm: 2,
                                md: 2
                            }), r.a.createElement(C.a, {
                                xs: 6,
                                sm: 6,
                                md: 6
                            }, r.a.createElement("div", {
                                align: "middle"
                            }, r.a.createElement("p", null, "4% ", this.props.languageFile.referral.reward), r.a.createElement("h5", null, this.props.languageFile.referral.referrals, " ", this.state.affCount2Sum, " "), r.a.createElement("h5", null, this.props.languageFile.referral.totalInvested, " ", this.state.tierInvest2Sum, " BNB"))), r.a.createElement(C.a, {
                                xs: 2,
                                sm: 2,
                                md: 2
                            }), r.a.createElement(C.a, {
                                xs: 6,
                                sm: 6,
                                md: 6
                            }, r.a.createElement("div", {
                                align: "middle"
                            }, r.a.createElement("p", null, "3% ", this.props.languageFile.referral.reward), r.a.createElement("h5", null, this.props.languageFile.referral.referrals, " ", this.state.affCount3Sum, " "), r.a.createElement("h5", null, this.props.languageFile.referral.totalInvested, " ", this.state.tierInvest3Sum, " BNB"))))))
                        }
                    }]), n
                }(n.Component);
            a(439);

            function G(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var a, n = Object(f.a)(e);
                    if (t) {
                        var r = Object(f.a)(this).constructor;
                        a = Reflect.construct(n, arguments, r)
                    } else a = n.apply(this, arguments);
                    return Object(y.a)(this, a)
                }
            }
            var _ = function(e) {
                    Object(m.a)(a, e);
                    var t = G(a);

                    function a() {
                        return Object(d.a)(this, a), t.apply(this, arguments)
                    }
                    return Object(p.a)(a, [{
                        key: "render",
                        value: function() {
                            return r.a.createElement("div", {
                                className: "faq"
                            }, r.a.createElement(S.a, {
                                type: "flex",
                                justify: "center",
                                gutter: {
                                    xs: 0,
                                    sm: 0,
                                    md: 24
                                }
                            }, r.a.createElement(C.a, {
                                xs: 24,
                                sm: 24,
                                md: 12
                            }, r.a.createElement("div", {
                                className: "faqItemBox"
                            }, r.a.createElement("p", {
                                className: "question"
                            }, "How To Play"), r.a.createElement("p", {
                                className: "answer"
                            }, 'Deposit BNB to hire miners and get mining power. Your miners will go to work mining BNB every minute. You will earn 10% of your deposits per day under "BNB Mined".'), r.a.createElement("br", null), r.a.createElement("p", {
                                className: "answer"
                            }, "* Boosting Mining Power: Boosting every 30-60 minutes for a higher mining power! The higher the mining power, the more BNB you can mine per day!"))), r.a.createElement(C.a, {
                                xs: 24,
                                sm: 24,
                                md: 12
                            }, r.a.createElement("div", {
                                className: "faqItemBox"
                            }, r.a.createElement("p", {
                                className: "question"
                            }, "How come my referrals aren't showing | Where are they?"), r.a.createElement("p", {
                                className: "answer"
                            }, "Your referrals show up in the 'BNB Mined' Section of the miner dapp."), r.a.createElement("br", null), r.a.createElement("p", {
                                className: "answer"
                            }, "Referrals are 3-level and totally 12%."), r.a.createElement("br", null), r.a.createElement("p", {
                                className: "answer"
                            }, "Developers fees is 3%.")))))
                        }
                    }]), a
                }(n.Component),
                $ = a(823),
                ee = function(e) {
                    return r.a.createElement("div", {
                        onClick: function() {
                            if (!window.web3) return console.log("metamask not installed"), void k.a.info("Please use browser with BSC wallet installed to open the site.");
                            e.wallet.provider !== sessionStorage.wallet ? (sessionStorage.wallet = e.wallet.provider, e.readWeb3Instance(e.wallet)) : "0x00000000000000000000000000000000deadbeef" === e.address ? e.reconnect() : function() {
                                if (!window.web3) return console.log("metamask not installed"), void k.a.info("Please use browser with BSC wallet installed.");
                                try {
                                    window.web3.eth.requestAccounts()
                                } catch (e) {
                                    console.log(e)
                                }
                            }(), e.toggleDisplayWalletModal()
                        },
                        className: "walletItem"
                    }, r.a.createElement("img", {
                        src: "".concat("", "/static/images/wallet/").concat(e.wallet.id, ".png"),
                        alt: "png",
                        className: "walletImage"
                    }), r.a.createElement("h2", null, e.wallet.name))
                },
                te = {
                    METAMASK: {
                        id: "metamask",
                        name: "Metamask",
                        provider: "ethereum"
                    },
                    CLOVER: {
                        id: "clover",
                        name: "Clover",
                        provider: "clover"
                    },
                    TOKENPOCKET: {
                        id: "tokenpocket",
                        name: "TokenPocket",
                        provider: "ethereum"
                    },
                    BITMAP: {
                        id: "bitkeep",
                        name: "BitKeep",
                        provider: "ethereum"
                    },
                    TRUST: {
                        id: "trust",
                        name: "Trust",
                        provider: "ethereum"
                    },
                    SFP: {
                        id: "sfp",
                        name: "SafePal",
                        provider: "ethereum"
                    },
                    ONTO: {
                        id: "onto",
                        name: "ONTO",
                        provider: "onto"
                    },
                    MATHWALLET: {
                        id: "mathwallet",
                        name: "Math",
                        provider: "ethereum"
                    },
                    COIN98: {
                        id: "coin98",
                        name: "Coin98",
                        provider: "ethereum"
                    },
                    METAX: {
                        id: "metax",
                        name: "MetaX",
                        provider: "okexchain"
                    }
                },
                ae = (a(440), function(e) {
                    return r.a.createElement("div", {
                        className: "wallet"
                    }, r.a.createElement($.a, {
                        className: "close",
                        onClick: function() {
                            e.toggleDisplayWalletModal()
                        }
                    }), r.a.createElement("h1", null, "CONNECT WALLET"), r.a.createElement(S.a, {
                        justify: "space-around",
                        align: "middle",
                        gutter: {
                            xs: 5,
                            sm: 5,
                            md: 16
                        }
                    }, Object.values(te).map(function(t) {
                        return r.a.createElement(C.a, {
                            xs: 12,
                            sm: 12,
                            md: 12,
                            key: t.id
                        }, r.a.createElement(ee, {
                            wallet: t,
                            reconnect: e.reconnect,
                            address: e.address,
                            readWeb3Instance: e.readWeb3Instance,
                            toggleDisplayWalletModal: e.toggleDisplayWalletModal
                        }))
                    })))
                });
            a(441);

            function ne(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var a, n = Object(f.a)(e);
                    if (t) {
                        var r = Object(f.a)(this).constructor;
                        a = Reflect.construct(n, arguments, r)
                    } else a = n.apply(this, arguments);
                    return Object(y.a)(this, a)
                }
            }
            var re = function(e) {
                Object(m.a)(n, e);
                var t = ne(n);

                function n(e) {
                    var a;
                    return Object(d.a)(this, n), (a = t.call(this)).minimizeAddress = function() {
                        return a.props.address ? a.props.address.substring(0, 5) + "..." + a.props.address.substring(37, 42) + ". " + a.props.languageFile.homePage.balance + U(a.props.state.bnbBalance).format("0,0.[00]") + "BNB" : a.props.languageFile.notification.loginPrompt
                    }, a.isMobile = function() {
                        return !!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
                    }, a.toggleDisplayWalletModal = function() {
                        a.setState({
                            showWalletModal: !a.state.showWalletModal
                        })
                    }, a.state = {
                        showWalletModal: !1
                    }, a
                }
                return Object(p.a)(n, [{
                    key: "render",
                    value: function() {
                        var e, t = this;
                        return r.a.createElement("div", {
                            className: "token"
                        }, r.a.createElement("div", {
                            className: "banner",
                            align: "middle"
                        }, r.a.createElement("div", {
                            className: "promptSection"
                        }, r.a.createElement("img", {
                            src: a(212),
                            alt: "png"
                        }), r.a.createElement("h1", null, " Brand New Miner"), r.a.createElement("h1", null, r.a.createElement("span", null, "10%"), " Daily & ", r.a.createElement("span", null, "3000%"), " APR"), r.a.createElement("h1", null, r.a.createElement("span", null, ""), " "), r.a.createElement("h1", null, r.a.createElement("span", null, "Clear broswer History"), " OR ", r.a.createElement("span", null, "Cache")), r.a.createElement("div", {
                            className: "button"
                        }, r.a.createElement("a", {
                            href: "https://t.me/Bnbfaucetminer",
                            target: "_blank",
                            rel: "noopener noreferrer"
                        }, r.a.createElement("img", {
                            src: a(152),
                            alt: "telegram",
                            width: "25px"
                        }), "Telegram"),r.a.createElement("a", {
                            href: "https://busdlottery.online/",
                            target: "_blank",
                            rel: "noopener noreferrer"
                        }, r.a.createElement("img", {
                            src: a(152),
                            alt: "telegram",
                            width: "25px"
                        }), "Lottery"), r.a.createElement("a", {
                            href: "https://twitchain.online",
                            target: "_blank",
                            rel: "noopener noreferrer"
                        }, r.a.createElement("img", {
                            src: a(152),
                            alt: "",
                            width: "25px"
                        }), "Claim Coin "), r.a.createElement("a", {
                            href: "https://bscscan.com/address/0x9f3cE6C7dE4F9274e69e23442936dd23B97B2237",
                            target: "_blank",
                            rel: "noopener noreferrer"
                        }, r.a.createElement("img", {
                            src: a(442),
                            alt: "bscscan",
                            width: "25px",
                            style: {
                                background: "white"
                            }
                        }), "BscScan"), ), ), r.a.createElement("div", {
                            className: "walletWrapper",
                            align: "middle",
                            onClick: function() {
                                t.props.address && "0x00000000000000000000000000000000deadbeef" !== t.props.address ? t.props.disconnect() : t.toggleDisplayWalletModal()
                            }
                        }, this.props.address && "0x00000000000000000000000000000000deadbeef" !== this.props.address ? r.a.createElement("span", {
                            className: "address"
                        }, (e = this.props.address).length > 10 ? e = e.substring(0, 5) + "..." + e.substring(e.length - 5, e.length) : "") : r.a.createElement("span", {
                            className: "address"
                        }, "Connect Wallet")), r.a.createElement(B.a, {
                            visible: this.state.showWalletModal,
                            onCancel: this.toggleDisplayWalletModal,
                            footer: null,
                            centered: !0,
                            wrapClassName: "customModal"
                        }, r.a.createElement(ae, {
                            toggleDisplayWalletModal: this.toggleDisplayWalletModal,
                            address: this.props.address,
                            reconnect: this.props.reconnect,
                            readWeb3Instance: this.props.readWeb3Instance
                        }))), r.a.createElement("div", {
                            className: "dataContainer",
                            align: "middle"
                        }, r.a.createElement("div", {
                            className: "dataBoxWrap"
                        }, r.a.createElement("div", {
                            className: "rainbowWrap"
                        }, r.a.createElement("div", {
                            className: "rainbow"
                        })), r.a.createElement("div", {
                            className: "dataBox"
                        }, r.a.createElement("h2", null, U(this.props.state.contractBalance).format("0,0.[00]"), " BNB"), r.a.createElement("p", null, "Contract Balance"), r.a.createElement("img", {
                            src: a(166),
                            alt: "png"
                        })))), r.a.createElement(V, {
                            state: this.props.state,
                            bnbPrice: this.props.state.bnbPrice,
                            languageFile: this.props.languageFile,
                            lang: this.props.lang,
                            address: this.props.address
                        }), r.a.createElement(Y, {
                            languageFile: this.props.languageFile,
                            lang: this.props.lang,
                            address: this.props.address,
                            totalSupply: this.props.state.totalSupply
                        }), r.a.createElement(_, {
                            languageFile: this.props.languageFile
                        }))
                    }
                }]), n
            }(n.Component);

            function ie(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var a, n = Object(f.a)(e);
                    if (t) {
                        var r = Object(f.a)(this).constructor;
                        a = Reflect.construct(n, arguments, r)
                    } else a = n.apply(this, arguments);
                    return Object(y.a)(this, a)
                }
            }
            var se = function(e) {
                    Object(m.a)(a, e);
                    var t = ie(a);

                    function a(e) {
                        var n;
                        return Object(d.a)(this, a), (n = t.call(this, e)).checkContract = function() {
                            W.web3 && n.props.address && (clearInterval(n.timer), n.getContractData(), n.startEventWatcher())
                        }, n.startEventWatcher = Object(u.a)(c.a.mark(function e() {
                            return c.a.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                    case "end":
                                        return e.stop()
                                }
                            }, e)
                        })), n.openNotification = function(e, t) {
                            var a = {
                                message: r.a.createElement("p", {
                                    className: "investNotification"
                                }, n.props.languageFile.notification.buyEvent, r.a.createElement("span", {
                                    className: "justNow"
                                }, n.props.languageFile.notification.justNow)),
                                description: r.a.createElement("p", {
                                    className: "notificationDescription"
                                }, r.a.createElement("b", null, e, " "), n.props.languageFile.notification.invested, r.a.createElement("b", null, " ", U(t).format("0,0.[0000]"), " BNB ")),
                                duration: 2
                            };
                            E.a.open(a)
                        }, n.openVaultNotification = function(e, t, a) {
                            var i = {
                                message: r.a.createElement("p", {
                                    className: "investNotification"
                                }, n.props.languageFile.notification.depositEvent, r.a.createElement("span", {
                                    className: "justNow"
                                }, n.props.languageFile.notification.justNow)),
                                description: r.a.createElement("p", {
                                    className: "notificationDescription"
                                }, r.a.createElement("b", null, e, " "), n.props.languageFile.notification.staked, r.a.createElement("b", null, " ", t, " BNB "), n.props.languageFile.notification["plan".concat(a)]),
                                duration: 3
                            };
                            E.a.open(i)
                        }, n.getContractData = Object(u.a)(c.a.mark(function e() {
                            var t, a, r, i, s, o, l, u, d, p, m, y, f, g, h, b, v;
                            return c.a.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return clearTimeout(n.timeout), e.next = 3, W.cakeFactory.methods.getPair(x, R).call();
                                    case 3:
                                        return t = e.sent, e.next = 6, W.busd.methods.balanceOf(t).call();
                                    case 6:
                                        return a = e.sent, e.next = 9, W.wbnb.methods.balanceOf(t).call();
                                    case 9:
                                        return r = e.sent, i = parseInt(a) / parseInt(r), e.t0 = W.web3.utils, e.next = 14, W.web3.eth.getBalance(n.props.address);
                                    case 14:
                                        if (e.t1 = e.sent, s = e.t0.fromWei.call(e.t0, e.t1), n.setState({
                                                bnbPrice: i,
                                                bnbBalance: s
                                            }), !W.vipMiner) {
                                            e.next = 65;
                                            break
                                        }
                                        return e.prev = 18, e.t2 = W.web3.utils, e.next = 22, W.web3.eth.getBalance(n.props.address);
                                    case 22:
                                        return e.t3 = e.sent, o = e.t2.fromWei.call(e.t2, e.t3), e.t4 = W.web3.utils, e.next = 27, W.web3.eth.getBalance(W.vipMiner._address);
                                    case 27:
                                        return e.t5 = e.sent, l = e.t4.fromWei.call(e.t4, e.t5), e.next = 31, W.vipMiner.methods.EGGS_TO_HATCH_1MINERS().call();
                                    case 31:
                                        return u = e.sent, e.next = 34, W.vipMiner.methods.hatcheryMiners(n.props.address).call();
                                    case 34:
                                        return d = e.sent, e.next = 37, W.vipMiner.methods.getMyEggs().call({
                                            from: n.props.address
                                        });
                                    case 37:
                                        if (p = e.sent, m = 0, y = 0, f = 0, g = "Aug 09 2000 14:00:00 UTC", !(p > 0)) {
                                            e.next = 59;
                                            break
                                        }
                                        return e.t6 = W.web3.utils, e.next = 46, W.vipMiner.methods.calculateEggSell(p).call();
                                    case 46:
                                        return e.t7 = e.sent, m = e.t6.fromWei.call(e.t6, e.t7), e.next = 50, W.vipMiner.methods.calculateEggBuySimple(W.web3.utils.toWei("0.1")).call();
                                    case 50:
                                        return h = e.sent, y = h / u, e.next = 54, W.vipMiner.methods.lastHatch(n.props.address).call();
                                    case 54:
                                        b = e.sent, 1 * l > 0 && (v = (new Date).getTime(), f = m / (v / 1e3 - b) * 3600), Number(f) < 1e-6 && (f = 0), Number(m) < 1e-6 && (m = 0), g = K(new Date(1e3 * (parseInt(b) + 86400)));
                                    case 59:
                                        n.setState({
                                            contractBalance: l,
                                            nativeBalance: o,
                                            myMiners: d,
                                            myEarns: m,
                                            hireEstimates: y,
                                            bnbPerHour: f,
                                            barrelFullTime: g
                                        }), e.next = 65;
                                        break;
                                    case 62:
                                        e.prev = 62, e.t8 = e.catch(18), console.log(e.t8);
                                    case 65:
                                        n.timeout = setTimeout(function() {
                                            n.getContractData()
                                        }, 6e3);
                                    case 66:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, null, [
                                [18, 62]
                            ])
                        })), n.state = {
                            bnbBalance: 0,
                            tokenPrice: 0,
                            tokenValue: 0,
                            bnbPrice: 0,
                            logId: []
                        }, n
                    }
                    return Object(p.a)(a, [{
                        key: "componentDidMount",
                        value: function() {
                            var e = Object(u.a)(c.a.mark(function e() {
                                var t = this;
                                return c.a.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            this.timer = setInterval(function() {
                                                t.checkContract()
                                            }, 1e3), /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ? E.a.config({
                                                placement: "topLeft",
                                                top: 5
                                            }) : E.a.config({
                                                placement: "topLeft",
                                                bottom: 50
                                            });
                                        case 2:
                                        case "end":
                                            return e.stop()
                                    }
                                }, e, this)
                            }));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "componentDidUpdate",
                        value: function(e) {
                            this.props.address !== e.address && W.web3 && this.checkContract()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this;
                            return r.a.createElement(A.a, null, r.a.createElement(w.a, {
                                exact: !0,
                                path: "/",
                                render: function() {
                                    return r.a.createElement(re, {
                                        lang: e.props.lang,
                                        state: e.state,
                                        address: e.props.address,
                                        languageFile: e.props.languageFile,
                                        readWeb3Instance: e.props.readWeb3Instance,
                                        reconnect: e.props.reconnect,
                                        disconnect: e.props.disconnect
                                    })
                                }
                            }), r.a.createElement(w.a, {
                                render: function() {
                                    return r.a.createElement(re, {
                                        lang: e.props.lang,
                                        state: e.state,
                                        address: e.props.address,
                                        languageFile: e.props.languageFile,
                                        reconnect: e.props.reconnect,
                                        disconnect: e.props.disconnect
                                    })
                                }
                            }))
                        }
                    }]), a
                }(n.Component),
                oe = a(209),
                le = a.n(oe);
            a(811);

            function ce(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var a, n = Object(f.a)(e);
                    if (t) {
                        var r = Object(f.a)(this).constructor;
                        a = Reflect.construct(n, arguments, r)
                    } else a = n.apply(this, arguments);
                    return Object(y.a)(this, a)
                }
            }
            var ue = sessionStorage.getItem("lang") || "en",
                de = function(e) {
                    Object(m.a)(n, e);
                    var t = ce(n);

                    function n(e) {
                        var r;
                        return Object(d.a)(this, n), (r = t.call(this, e)).changeLang = function(e) {
                            r.setState({
                                lang: e
                            }, function() {
                                sessionStorage.lang = r.state.lang, r.getInitialLang()
                            })
                        }, r.readWeb3Instance = function() {
                            var e = null;
                            "undefined" !== typeof window.ethereum ? (window.ethereum.enable(), (e = new le.a(window.ethereum)).eth.getAccounts().then(function(e) {
                                r.setState({
                                    address: e[0]
                                })
                            }).catch(function(e) {
                                console.log(e)
                            }), W.setWeb3(e)) : "undefined" !== typeof window.web3 ? (e = new le.a(window.web3.currentProvider)).eth.defaultAccount ? (console.log(e), r.setState({
                                address: e.eth.defaultAccount
                            }, function() {
                                W.setWeb3(e)
                            })) : (e.eth.getAccounts().then(function(e) {
                                r.setState({
                                    address: e[0]
                                })
                            }).catch(function(e) {
                                console.log(e)
                            }), W.setWeb3(e)) : (console.error("wait for MetaMask"), setTimeout(Object(u.a)(c.a.mark(function e() {
                                return c.a.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.next = 2, r.readWeb3Instance();
                                        case 2:
                                        case "end":
                                            return e.stop()
                                    }
                                }, e)
                            })), 500))
                        }, r.disconnect = function() {
                            var e = r.state.address;
                            r.setState({
                                address: "0x00000000000000000000000000000000deadbeef",
                                tempAddress: e
                            })
                        }, r.reconnect = function() {
                            r.setState({
                                address: r.state.tempAddress
                            })
                        }, r.state = {
                            lang: "en",
                            address: null,
                            languageFile: a(167)("./" + ue + ".json")
                        }, r
                    }
                    return Object(p.a)(n, [{
                        key: "getInitialLang",
                        value: function() {
                            var e = sessionStorage.getItem("lang") || "en";
                            sessionStorage.lang = e, this.setState({
                                lang: e,
                                languageFile: a(167)("./" + e + ".json")
                            })
                        }
                    }, {
                        key: "componentDidMount",
                        value: function() {
                            var e = Object(u.a)(c.a.mark(function e() {
                                var t = this;
                                return c.a.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            this.getInitialLang(), this.readWeb3Instance(), "undefined" !== typeof window.ethereum ? window.ethereum.on("accountsChanged", function(e) {
                                                t.readWeb3Instance()
                                            }) : "undefined" !== typeof window.web3 && console.log(window.web3), localStorage.vaultEventStatus = "false";
                                        case 4:
                                        case "end":
                                            return e.stop()
                                    }
                                }, e, this)
                            }));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "render",
                        value: function() {
                            return r.a.createElement("div", {
                                className: "App",
                                align: "middle"
                            }, r.a.createElement("div", {
                                className: "mainContianer"
                            }, r.a.createElement(se, {
                                lang: this.state.lang,
                                address: this.state.address,
                                languageFile: this.state.languageFile,
                                disconnect: this.disconnect,
                                reconnect: this.reconnect,
                                readWeb3Instance: this.readWeb3Instance
                            }), r.a.createElement(v, {
                                lang: this.state.lang,
                                languageFile: this.state.languageFile
                            })))
                        }
                    }]), n
                }(n.Component);
            s.a.render(r.a.createElement(o.a, null, r.a.createElement(de, null)), document.getElementById("root"))
        }
    },
    [
        [356, 1, 2]
    ]
]);
//# sourceMappingURL=main.ffad696d.chunk.js.map